import os
import time
import pickle
import math
import requests
from contextlib import contextmanager
import numpy as np
import torch
from geopy import distance
from geopy.distance import lonlat
from obspy import UTCDateTime
import matplotlib.pyplot as plt
import networkx as nx
from obspy import read as obsread
from scipy import signal
from sklearn.model_selection import StratifiedShuffleSplit
from torch import nn
from tqdm import tqdm

from definitions import QUAKES_CRAWLED_DATA_PATH, QUAKES_RAW_DATA_PATH

QUAKES_API = "https://service.geonet.org.nz/fdsnws/event/1/query?format=text&start={}&end={}&format=text"
WAVES_API = "https://service.geonet.org.nz/fdsnws/dataselect/1/query?network=NZ&station={}&location=10&channel=HHZ&starttime={}&endtime={}"


def read_pickle(path):
    with open(path, 'rb') as f:
        content = pickle.load(f)
    return content

def write_pickle(data, path):
    with open(path, 'wb') as f:
        pickle.dump(data, f)


def UTCDateTime_to_string(timestamp: UTCDateTime):
    assert not timestamp.microsecond
    return timestamp.isoformat().replace(":", "_")


def string_to_UTCDateTime(timestamp_str: str):
    assert " " not in timestamp_str
    assert "T" in timestamp_str
    return UTCDateTime(timestamp_str.replace("_", ":"))


def quake_filename_to_UTCDateTime(filename):
    return string_to_UTCDateTime(filename.split("quake_")[1].split(".")[0])


def get_earthquakes_in_timespan(url: str):
    """
        'start' and 'end' have to be ISO format (such as "2019-06-01T00:00:00.000").
        'url' must be already built before calling this function.
    """
    res = requests.get(url)

    lines = res.text.split("\n")
    names = lines[0].split(" | ")

    all_quakes_dictionaries = []
    for line in lines[1:]:
        quake_dict = {name.lower().strip(): value for name, value in zip(names, line.split("|"))}
        if len(quake_dict) == len(names):
            all_quakes_dictionaries.append(quake_dict)
    return all_quakes_dictionaries



@contextmanager
def timeit_context(name):
    startTime = time.time()
    yield
    elapsedTime = time.time() - startTime
    print('[{}] finished in {} s\n'.format(name, int(elapsedTime)))





def obtain_data(start: UTCDateTime, end: UTCDateTime, stations_to_query: list, expected_samples: int):
    """
            'start' and 'end' have to be UTCDateTime objects
        """

    mseed_obj_for_stations = query_all_stations(stations_to_query, start, end)

    assert len(mseed_obj_for_stations) == len(stations_to_query)

    data_to_fill = np.zeros((len(stations_to_query), expected_samples))

    for stream_idx, stream in enumerate(mseed_obj_for_stations):
        if stream_idx % 15 == 0:
            print(f"Stream number: {stream_idx}")
        #         print(stream.stats)

        assert stream.stats.delta == 0.01

        stream_starttime = stream.stats.starttime
        stream_endtime = stream.stats.endtime
        stream_data = stream.data

        cut_data = cut_obtained_data(stream_data, start, end, stream_starttime, stream_endtime)

        tolerance = 0
        if abs(cut_data.shape[0] - expected_samples) > tolerance:
            raise BadDataException(f"Found {cut_data.shape[0]} samples, expected {expected_samples}")

        data_to_fill[stream_idx, :] = cut_data
    return data_to_fill


def query_all_stations(stations_to_query, start, end):

    mseeds = []
    for selected_station in stations_to_query:
        query_url = WAVES_API.format(selected_station, start.isoformat(), end.isoformat())
        mseed_for_station = obsread(query_url)[0]
        mseeds.append(mseed_for_station)

    return mseeds


class BadDataException(Exception):
    def __init__(self, message):

        # Call the base class constructor with the parameters it needs
        super().__init__(message)

def cut_obtained_data(data, query_start, query_end, obtained_start, obtained_end):
    # We expect 'obtained_start' <= 'query_start'
    if obtained_start > query_start:
        delta = obtained_start - query_start
        if delta > 0.01:
            raise BadDataException(
                f"The obtained start is greater than the queried start by: {delta}. Queried: {query_start}. Obtained: {obtained_start}")
        else:
            obtained_start = query_start

    # We expect 'obtained_end' >= 'query_end'
    if obtained_end < query_end:
        delta = query_end - obtained_end
        if delta > 0.01:
            raise BadDataException(
                f"The obtained end is smaller than the queried end by: {delta}. Queried: {query_end}. Obtained: {obtained_end}")
        else:
            obtained_end = query_end

    starting_offset = 100 * (query_start - obtained_start)
    ending_offset = 100 * (obtained_end - query_end)

    starting_offset_rounded = math.ceil(starting_offset)
    ending_offset_rounded = math.ceil(ending_offset)

    cut_data = data[starting_offset_rounded:-ending_offset_rounded or None]
    return cut_data


def resample_data(raw_data, desired_timesteps):
    """
        raw_data is of shape [batch x stations x timesteps]
    """
    new_data = np.zeros((raw_data.shape[0], raw_data.shape[1], desired_timesteps))
    for i in range(raw_data.shape[0]):
        resampled_signal = signal.resample(raw_data[i], desired_timesteps, axis=1)
        new_data[i] = resampled_signal
    return new_data

"""
OLD VERSION OF CRAWLING

# delta_seconds = 20

# # now = datetime.datetime.now().isoformat().replace(":", "_").replace(".", "_")
# # dataset_folder = f"./quake_data/{now}_delta={delta_seconds}"

# dataset_folder = f"./quake_data/dataset_delta={delta_seconds}/"

# check_create_folder(dataset_folder)
# print(dataset_folder)

# quakes = [file for file in os.listdir(dataset_folder) if file.endswith(".npy")]
# print(f"{len(quakes)} earthquakes found in dataset ({dataset_folder}).")


# for quake_id, earthquake_dict in enumerate(all_quakes_dictionaries):
    
#     with timeit_context('Quake retrieval'):
        
#         print(f"\n\nQuake number: {quake_id} | time: {earthquake_dict['time']}")

#         does_file_exist = f"quake_{quake_id}.npy" in quakes
#         if does_file_exist:
#             print(f"Quake {quake_id} already saved. Continue.")
#             continue
              
#         q_timestamp = UTCDateTime(dateutil.parser.parse(earthquake_dict['time']))
#         before_quake = UTCDateTime(q_timestamp - datetime.timedelta(seconds=delta_seconds))
#         after_quake = UTCDateTime(q_timestamp + datetime.timedelta(seconds=delta_seconds))


#         expected_samples = 100 * delta_seconds
#         stations_to_query = filtered_stations[0].values


#         # GET WAVES BEFORE
#         with timeit_context('Waves before'):
#             start = before_quake
#             end = q_timestamp
#             print(f"\n\nBefore. Expected samples: {expected_samples}")
#             print(f"Start_time: {start} . End_time: {end }")
#             before_data = obtain_data(
#                 start=start, end=end,
#                 stations_to_query=stations_to_query, expected_samples=expected_samples
#             )

#             earthquake_dict['before_data'] = before_data  


#         # GET WAVES AFTER
#         with timeit_context('Waves after'):
#             start = q_timestamp
#             end = after_quake
#             print(f"\n\nAfter. Expected samples: {expected_samples}")
#             print(f"Start_time: {start} . End_time: {end}")
#             after_data = obtain_data(
#                 start=start, end=end,
#                 stations_to_query=stations_to_query, expected_samples=expected_samples
#             )

#             earthquake_dict['after_data'] = after_data      


#         with open(f'{dataset_folder}/quake_{quake_id}.npy', 'wb') as handle:
#             pickle.dump(earthquake_dict, handle, protocol=pickle.HIGHEST_PROTOCOL)
"""


def get_quakes_dataset(wave_length: int, hertz: int):
    crawled_dataset_path = os.path.join(QUAKES_CRAWLED_DATA_PATH, f"dataset_delta={wave_length}", "processed")
    data = np.load(os.path.join(crawled_dataset_path, f"X_downsampledAt={hertz}hz.npy"))
    labels = np.load(os.path.join(crawled_dataset_path, "y.npy"))
    assert data.shape[0] == labels.shape[0]

    adjacency_matrix = pickle.load(open(os.path.join(QUAKES_RAW_DATA_PATH, "Adj.p"), 'rb'))
    adjacency_matrix = torch.from_numpy(adjacency_matrix).numpy()
    assert adjacency_matrix.shape[0] == data.shape[1]
    return data, labels, adjacency_matrix


def split_transform_quake_data(data, labels, splits, seconds_to_keep, normalize, device):
    indices = list(range(data.shape[0]))
    trn_idx, val_idx, tst_idx = np.split(np.random.permutation(indices),
                                         [int(len(indices) * splits[0]),
                                          int(len(indices) * sum(splits[:-1]))])

    if normalize:
        norm_metadata = {}
        normalization_indices = np.concatenate((trn_idx, val_idx))  # compute normalization based on trn + val
        for i in range(data.shape[1]):
            station_metadata = {}
            station_data_for_normalization = data[normalization_indices, i, :]
            station_metadata['mean'] = np.mean(station_data_for_normalization)
            station_metadata['std'] = np.std(station_data_for_normalization)
            norm_metadata[i] = station_metadata

            # normalize ALL data using the values computed with the normalization data
            data[:, i, :] = (data[:, i, :] - station_metadata['mean']) / station_metadata['std']

    # data has to be [batch_size, input_features, n_of_nodes, n_of_timesteps]
    data = torch.from_numpy(data).to(device).float().unsqueeze(1)
    labels = torch.from_numpy(labels).to(device).float()

    data = data[:, :, :, :seconds_to_keep * 2]  # we have 2 samples per seconds


    trn_data, trn_labels = data[trn_idx], labels[trn_idx]
    val_data, val_labels = data[val_idx], labels[val_idx]
    tst_data, tst_labels = data[tst_idx], labels[tst_idx]

    return trn_idx, val_idx, tst_idx, trn_data, trn_labels, val_data, val_labels, tst_data, tst_labels, norm_metadata if normalize else None


class CELossWithSparsityRegularizer(nn.Module):
    def __init__(self, model, lambda_value: float):
        super().__init__()
        self.model = model
        self.lmbda = lambda_value
        self.ce = nn.CrossEntropyLoss()

    def forward(self, yhat, y):
        initial_CE_loss = self.ce(yhat, y)

        regularization_loss = torch.zeros(1).to(yhat.device)
        parametric_weights = [weight for (name, weight) in self.model.named_parameters() if 's_' in name]
        for tens in parametric_weights:
            regularization_loss += torch.abs(tens)

        final_loss = initial_CE_loss + self.lmbda * regularization_loss

        return final_loss



def process_quake_data(data, labels, splits, normalize, device):
    N_stations = data.shape[1]

    train_val_indices, test_indices = next(StratifiedShuffleSplit(n_splits=1, test_size=splits[2]).split(data, labels))
    normalization_data = data[train_val_indices]

    metadata_dict = None
    if normalize:
        normalized_data = np.zeros(data.shape)
        metadata_dict = {}
        for station_idx in range(N_stations):
            station_metadata = {}
            station_data_for_normalization = normalization_data[:, station_idx, :]
            station_metadata['mean'] = np.mean(station_data_for_normalization)
            station_metadata['std'] = np.std(station_data_for_normalization)
            metadata_dict[station_idx] = station_metadata

            # normalize ALL data using the values computed with the normalization data
            normalized_data[:, station_idx, :] = (data[:, station_idx, :] - station_metadata['mean']) / station_metadata['std']
        data = normalized_data


    # data has to be [batch_size, input_features, n_of_nodes, n_of_timesteps]
    data = torch.from_numpy(data).to(device).float().unsqueeze(1)
    labels = torch.from_numpy(labels).to(device).float()

    train_val_data, train_val_labels = data[train_val_indices], labels[train_val_indices]
    train_indices, val_indices = next(StratifiedShuffleSplit(n_splits=1, test_size=splits[1]/sum(splits[:-1])).split(train_val_data.cpu(), train_val_labels.cpu()))

    trn_data, trn_labels = train_val_data[train_indices], train_val_labels[train_indices]
    val_data, val_labels = train_val_data[val_indices], train_val_labels[val_indices]
    tst_data, tst_labels = data[test_indices], labels[test_indices]

    assert torch.unique(torch.cat([trn_data, val_data, tst_data], dim=0), dim=0).shape[0] == labels.shape[0]
    # print(sorted(test_indices))

    return trn_data, trn_labels, val_data, val_labels, tst_data, tst_labels, metadata_dict


def is_point_in_bbox(point, bbox):
    point_long = point[0]
    point_lat = point[1]

    left_lower_long, upper_right_long, left_lower_lat, upper_right_lat = bbox

    return (left_lower_long <= point_long <= upper_right_long) and (left_lower_lat <= point_lat <= upper_right_lat)


def custom_geo_distance(x, y):
    return distance.great_circle(lonlat(*x), lonlat(*y)).kilometers


def find_closest_station(quake_coords, stations):
    all_distances = [custom_geo_distance(quake_coords, station) for station in stations]
    return np.argmin(all_distances), np.min(all_distances)


def visualize_sensors_graph(longitudes, latitudes, adjacency, basemap, nodesize, nodecolor, draw_edges, edgecolors,
                            alpha, width=0.5, title="", with_labels=False):
    mapped_x, mapped_y = basemap(longitudes, latitudes)
    g = nx.Graph()

    positions = {}
    for idx in range(len(mapped_x)):
        g.add_edge(idx, idx)
        positions[idx] = (mapped_x[idx], mapped_y[idx])

    if draw_edges:
        for i in range(adjacency.shape[0]):
            for j in range(adjacency.shape[0]):
                if adjacency[i, j] != 0:
                    g.add_edge(i, j)

    nx.draw_networkx(g, positions, node_size=nodesize, node_color=nodecolor, with_labels=with_labels, alpha=alpha,
                     edge_color=edgecolors, width=width)
    basemap.bluemarble()
    plt.title(title)


def visualize_quakes(longitudes, latitudes, basemap, nodesize, nodecolor, alpha, title):
    mapped_x, mapped_y = basemap(longitudes, latitudes)
    g = nx.Graph()

    positions={}
    for idx in range(len(mapped_x)):
        g.add_edge(idx, idx)
        positions[idx] = (mapped_x[idx], mapped_y[idx])

    nx.draw_networkx(g, positions, node_size=nodesize, node_color=nodecolor, with_labels=False, alpha=alpha)
    basemap.bluemarble()
    plt.title(title)


def create_weighted_adjacency_quakes(dist_matrix, threshold):
    # dist_matrix contains all the pairwise distances
    assert dist_matrix.shape[0] == 58

    # check all values are non-zero except diagonal
    for j in range(dist_matrix.shape[0]):
        for i in range(dist_matrix.shape[1]):
            if i == j:
                assert dist_matrix[i][j] == 0
            else:
                assert dist_matrix[i][j] != 0

    # First, we build the adjacency matrix to obtain average degree = 10 (threshold is tuned beforehand for this)
    adjacency_matrix = dist_matrix.copy()
    adjacency_matrix[adjacency_matrix > threshold] = 0  # nodes above threshold are not connected

    # Then, we compute the average distance between connected nodes
    avg_distance_of_connected_nodes = np.mean(adjacency_matrix[adjacency_matrix > 0])

    print(f"Average distance of connected nodes: {round(avg_distance_of_connected_nodes, 3)} kilometers.")

    # Then, we build the weights of the graph by using a Gaussian kernel
    weights_kernel = adjacency_matrix.copy()

    for i in range(weights_kernel.shape[0]):
        for j in range(weights_kernel.shape[1]):
            if weights_kernel[i, j] == 0:
                # there is no edge, no need to compute the weight between the stations
                continue
            else:
                distance_ij = dist_matrix[i, j]
                new_weight = round(np.exp(-distance_ij / avg_distance_of_connected_nodes), 5)
                weights_kernel[i, j] = new_weight

    return adjacency_matrix, weights_kernel


def k_hop_reach(Graph, start_node, n_hops):
    reach = {start_node}
    for _ in range(n_hops):
        for node in reach:
            reach = reach.union(set(Graph[node]))
    return sorted(reach)


def recalls_at_k_hops(conf_matrix, k, weighted_adjacency, class_to_station_dict, n_of_decimals, verbose):

    n_classes = weighted_adjacency.shape[0]
    sensor_graph = nx.from_numpy_array(weighted_adjacency)
    k_reaches = {node_idx: k_hop_reach(sensor_graph, node_idx, k) for node_idx in range(n_classes)}

    recalls = []
    supports = []
    for target_class in range(conf_matrix.shape[0]):
        target_station = class_to_station_dict[target_class]
        station_k_reach = k_reaches[target_station]

        # Predictions for all samples coming from 'target' class --> i-th row of confusion matrix
        target_class_predictions = conf_matrix[target_class]

        # We get the support for the target class.
        # For us, this is the sum of the entire row of the confusion matrix for the 'target' class
        n_samples_for_class = sum(target_class_predictions)
        if n_samples_for_class == 0:
            if verbose:
                print(f"recall is ill-defined for class {target_class}. Set to 0.0")
            recalls.append(0)
            supports.append(0)
            continue

        # We convert the predictions from classes to stations, so that we can compare with the neighborhoods
        target_class_predictions_converted = {
            class_to_station_dict[idx]: preds for idx, preds in enumerate(target_class_predictions)
        }

        # How many times we predict a station which is in the neighborhood of the 'target' station
        predictions_in_neighborhood = sum(
            [preds for stat, preds in target_class_predictions_converted.items() if stat in station_k_reach]
        )

        recall_for_class = round(predictions_in_neighborhood / n_samples_for_class, n_of_decimals)

        recalls.append(recall_for_class)
        supports.append(n_samples_for_class)

    return recalls, supports


def precisions_at_k_hops(conf_matrix, k, weighted_adjacency, class_to_station_dict, n_of_decimals, verbose):
    n_classes = weighted_adjacency.shape[0]
    sensor_graph = nx.from_numpy_array(weighted_adjacency)
    k_reaches = {node_idx: k_hop_reach(sensor_graph, node_idx, k) for node_idx in range(n_classes)}

    precisions = []
    supports = []
    for target_class in range(conf_matrix.shape[0]):
        target_station = class_to_station_dict[target_class]
        station_k_reach = k_reaches[target_station]

        support = sum(conf_matrix[target_class])
        supports.append(support)

        # Predictions for all samples predicted as 'target' class --> i-th column of confusion matrix
        classified_as_target = conf_matrix[:, target_class]

        # We get how many samples are classified as 'target' class
        n_predictions_for_class = sum(classified_as_target)
        if n_predictions_for_class == 0:
            if verbose:
                print(f"precision is ill-defined for class {target_class}. Set to 0.0")
            precisions.append(0)
            continue

        # We convert the predictions from classes to stations, so that we can compare with the neighborhoods
        classified_as_target_converted = {
            class_to_station_dict[idx]: preds for idx, preds in enumerate(classified_as_target)
        }

        # How many times we predict a station which is in the neighborhood of the 'target' station
        predictions_in_neighborhood = sum(
            [preds for stat, preds in classified_as_target_converted.items() if stat in station_k_reach]
        )

        prediction_for_class = round(predictions_in_neighborhood / n_predictions_for_class, n_of_decimals)

        precisions.append(prediction_for_class)

    return precisions, supports


def f1_scores_at_k_hops(conf_matrix, k, weighted_adjacency, class_to_station_dict, n_of_decimals, verbose):
    recalls, supports = recalls_at_k_hops(conf_matrix, k, weighted_adjacency, class_to_station_dict, n_of_decimals, verbose)
    precisions, _ = precisions_at_k_hops(conf_matrix, k, weighted_adjacency, class_to_station_dict, n_of_decimals, verbose)

    f1_scores = []
    for idx, (prec, rec) in enumerate(zip(precisions, recalls)):
        if (prec + rec) == 0:
            if verbose:
                print(f"f1 score is ill-defined for class {idx}. Set to 0.0")
            f1_scores.append(0)
            continue

        f1_score_per_class = 2 * (prec * rec)/(prec + rec)
        f1_scores.append(round(f1_score_per_class, n_of_decimals))

    return f1_scores, supports


def compute_metrics_with_growing_radius(cm, distance_matrix, start, stop, step, station_to_class_dict, verbose):
    n_stations = distance_matrix.shape[0]

    metrics_dict = {}

    for station_index in tqdm(range(n_stations)):
        corresponding_class = station_to_class_dict.get(station_index, None)
        if corresponding_class is None:
            continue
        distances_for_station = distance_matrix[station_index]

        recalls_for_station = []
        precisions_for_station = []
        f1_scores_for_station = []

        class_cm_row = cm[corresponding_class]
        class_cm_column = cm[:, corresponding_class]

        for radius in np.arange(start, stop, step):
            # computation of metrics given a radius

            stations_within_radius = [i for i in range(n_stations) if (distances_for_station <= radius)[i]]
            classes_within_radius = [station_to_class_dict[i] for i in stations_within_radius if i in station_to_class_dict]

            row_entries_within_radius = [preds for cls_idx, preds in enumerate(class_cm_row) if cls_idx in classes_within_radius]
            column_entries_within_radius = [preds for cls_idx, preds in enumerate(class_cm_column) if cls_idx in classes_within_radius]

            # RECALL
            n_of_target_class_samples = sum(class_cm_row)
            if n_of_target_class_samples == 0:
                recall_within_radius = 0
                if verbose:
                    print(f"Recall is ill-defined for station {station_index}")
            else:
                recall_within_radius = sum(row_entries_within_radius) / n_of_target_class_samples
            recalls_for_station.append(recall_within_radius)


            # PRECISION
            n_of_samples_classified_as_target_class = sum(class_cm_column)
            if n_of_samples_classified_as_target_class == 0:
                precision_within_radius = 0
                if verbose:
                    print(f"Precisions is ill-defined for station {station_index}")
            else:
                precision_within_radius = sum(column_entries_within_radius) / n_of_samples_classified_as_target_class
            precisions_for_station.append(precision_within_radius)


            # F1-SCORE
            if (precision_within_radius + recall_within_radius) == 0:
                f1_score = 0
                if verbose:
                    print(f"f1 score is ill-defined for station {station_index}")
            else:
                f1_score = 2 * precision_within_radius * recall_within_radius / (precision_within_radius + recall_within_radius)
            f1_scores_for_station.append(f1_score)

        metrics_dict[station_index] = {
            'recalls': recalls_for_station,
            'precisions': precisions_for_station,
            'f1_scores': f1_scores_for_station,
        }


    # ACCURACY
    # Accuracy is for the whole model and cannot be defined per class.
    accuracies = []

    for radius in np.arange(start, stop, step):

        predictions_considered_correct = 0
        for station_index in range(n_stations):
            corresponding_class = station_to_class_dict.get(station_index, None)
            if corresponding_class is None:
                continue
            distances_for_station = distance_matrix[station_index]

            stations_within_radius = [i for i in range(n_stations) if (distances_for_station <= radius)[i]]
            classes_within_radius = [station_to_class_dict[i] for i in stations_within_radius if i in station_to_class_dict]

            class_cm_column = cm[:, corresponding_class]
            column_entries_within_radius = [preds for cls_idx, preds in enumerate(class_cm_column) if cls_idx in classes_within_radius]
            predictions_considered_correct += sum(column_entries_within_radius)

        accuracy_for_radius = predictions_considered_correct / np.sum(cm)
        accuracies.append(accuracy_for_radius)

    metrics_dict['accuracies'] = accuracies
    return metrics_dict




def compute_metrics_with_growing_radius_v2(cm, distance_matrix, start, stop, step, station_to_class_dict, verbose):
    n_stations = distance_matrix.shape[0]

    metrics_dict = {}

    # RECALL, PRECISION, and F1 SCORE are defined per class, since we have to consider the neighborhood of a chosen station

    for station_index in tqdm(range(n_stations)):
        corresponding_class = station_to_class_dict.get(station_index, None)
        if corresponding_class is None:
            continue
        distances_for_station = distance_matrix[station_index]

        recalls_for_station = []
        precisions_for_station = []
        f1_scores_for_station = []

        for radius in np.arange(start, stop, step):
            # computation of metrics given a radius

            stations_within_radius = [i for i in range(n_stations) if (distances_for_station <= radius)[i]]
            classes_within_radius = [station_to_class_dict[i] for i in stations_within_radius if i in station_to_class_dict]

            class_cm_rows = cm[classes_within_radius]
            class_cm_columns = cm[:, classes_within_radius]

            correctly_predicted_in_radius = np.sum(class_cm_rows[:, classes_within_radius])
            assert (class_cm_rows[:, classes_within_radius] == class_cm_columns[classes_within_radius, :]).all()

            # RECALL
            n_of_samples_from_stations_in_radius = np.sum(class_cm_rows)
            if n_of_samples_from_stations_in_radius == 0:
                recall_within_radius = 0
                if verbose:
                    print(f"Recall is ill-defined for station {station_index}")
            else:
                recall_within_radius = correctly_predicted_in_radius / n_of_samples_from_stations_in_radius
            recalls_for_station.append(recall_within_radius)


            # PRECISION
            n_of_samples_predicted_in_radius = np.sum(class_cm_columns)
            if n_of_samples_predicted_in_radius == 0:
                precision_within_radius = 0
                if verbose:
                    print(f"Precisions is ill-defined for station {station_index}")
            else:
                precision_within_radius = correctly_predicted_in_radius / n_of_samples_predicted_in_radius
            precisions_for_station.append(precision_within_radius)


            # F1-SCORE
            if (precision_within_radius + recall_within_radius) == 0:
                f1_score = 0
                if verbose:
                    print(f"f1 score is ill-defined for station {station_index}")
            else:
                f1_score = 2 * precision_within_radius * recall_within_radius / (precision_within_radius + recall_within_radius)
            f1_scores_for_station.append(f1_score)


            # if f1_score > 0 and station_index == 33:
            #     print()

        metrics_dict[station_index] = {
            'recalls': recalls_for_station,
            'precisions': precisions_for_station,
            'f1_scores': f1_scores_for_station,
        }


    # ACCURACY
    # Accuracy is for the whole model and cannot be defined per class.
    accuracies = []

    for radius in np.arange(start, stop, step):

        predictions_considered_correct = 0
        for station_index in range(n_stations):
            corresponding_class = station_to_class_dict.get(station_index, None)
            if corresponding_class is None:
                continue
            distances_for_station = distance_matrix[station_index]

            stations_within_radius = [i for i in range(n_stations) if (distances_for_station <= radius)[i]]
            classes_within_radius = [station_to_class_dict[i] for i in stations_within_radius if i in station_to_class_dict]

            class_cm_column = cm[:, corresponding_class]
            column_entries_within_radius = [preds for cls_idx, preds in enumerate(class_cm_column) if cls_idx in classes_within_radius]
            predictions_considered_correct += sum(column_entries_within_radius)


            # if station_index == 33:
            #     print()

        accuracy_for_radius = predictions_considered_correct / np.sum(cm)
        accuracies.append(accuracy_for_radius)

    metrics_dict['accuracies'] = accuracies
    return metrics_dict








