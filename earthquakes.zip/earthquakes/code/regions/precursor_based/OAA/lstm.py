import datetime
from collections import Counter

from torch import nn
from torch.optim.lr_scheduler import StepLR
from win10toast import ToastNotifier

from architectures.lstm import MV_LSTM
from definitions import QUAKES_NEW_DATASET_PATH
import numpy as np
import os
import torch

# torch.manual_seed(123)
# np.random.seed(123)
# random.seed(123)

from earthquakes.quakes_util import read_pickle, process_quake_data, write_pickle
from prediction.pred_utils import get_device
from prediction.train_utils import train_model_quakes, perform_chunk_predictions, accuracy_classification, \
    compute_confusion_matrix
from utils.misc_utils import check_create_folder
device = get_device(use_gpu=False)

###############################################################################################################

OAA_dict = read_pickle("OAA_dict.pickle")
orig_data = np.load(os.path.join(QUAKES_NEW_DATASET_PATH, "data_downsampledAt2Hz.npy"))
# No need for labels since we will relabel data based on pos/neg class indices



################################## PARAMETERS #################################
data_splits = [0.5, 0.25, 0.25]
N_CLASSES_FOR_OAA = 45
BEFORE_SAMPLES = 20     # 2 samples --> 1 second of recording
AFTER_SAMPLES = 0
N_ITERATIONS = 20
PERCENTAGE_OF_TRAINING_DATA_TO_KEEP = 1.00

num_epochs = 300
learning_rate = 0.005 # 0.0005
weight_decay = 0.0005
batch_size = 200
not_learning_limit = 100
step_size = 100
gamma_step = 0.8
hidden_units = 8
###############################################################################

for positive_class in range(N_CLASSES_FOR_OAA):

    if positive_class != 22:
        continue

    print(f"POSITIVE CLASS: {positive_class}")


    positive_indices, negative_indices = OAA_dict[positive_class]['pos_indices'], OAA_dict[positive_class]['neg_indices']

    positive_samples = np.take(orig_data, positive_indices, axis=0)
    negative_samples = np.take(orig_data, negative_indices, axis=0)

    data = np.concatenate((positive_samples, negative_samples), axis=0)
    labels = np.concatenate((np.ones(positive_samples.shape[0]), np.zeros(negative_samples.shape[0])), axis=0)
    assert data.shape[0] == labels.shape[0]

    c = Counter(list(labels.tolist()))
    print(c.most_common())

    # 20 samples represent 10 seconds of data (it is recorded at two hertz)
    start = int(data.shape[2]/2) - BEFORE_SAMPLES
    end = int(data.shape[2]/2) + AFTER_SAMPLES
    data = data[:, :, start:end]



    tst_accuracies_best = []
    tst_accuracies_last = []
    best_models_confusion_matrices = []
    last_models_confusion_matrices = []
    for i in range(N_ITERATIONS):
        print(f"Iteration {i}")

        ############################################# DATA ########################################################################
        trn_data, trn_labels, val_data, val_labels, tst_data, tst_labels, norm_metadata = process_quake_data(
            data.copy(), labels, data_splits, normalize=True, device=device)

        trn_data = trn_data[:int(PERCENTAGE_OF_TRAINING_DATA_TO_KEEP * trn_data.shape[0])]
        trn_labels = trn_labels[:int(PERCENTAGE_OF_TRAINING_DATA_TO_KEEP * trn_labels.shape[0])]
        print(f"Selecting {PERCENTAGE_OF_TRAINING_DATA_TO_KEEP * 100}% of the training set.")
        print(f"[NEW]. Trn samples: {trn_data.shape[0]} | Val samples: {val_data.shape[0]} | Tst samples: {tst_data.shape[0]}")

        N_spatial_nodes = trn_data.shape[2]
        obs_window = trn_data.shape[3]
        n_classes = len(np.unique(labels))
        assert n_classes == 2

        trn_data = trn_data.squeeze(1).transpose(dim0=1, dim1=2)
        val_data = val_data.squeeze(1).transpose(dim0=1, dim1=2)
        tst_data = tst_data.squeeze(1).transpose(dim0=1, dim1=2)

        print(f"{N_spatial_nodes} nodes | Observation window: {obs_window} | {n_classes} classes")
        print(f"Training samples: {trn_data.shape[0]} | Validation samples: {val_data.shape[0]} | test samples: {tst_data.shape[0]}")

        ##################################################################################################################################

        c = Counter(list(val_labels.tolist()))
        print(f"Percentages on validation set: {round(c[0] / sum(c.values()), 3), round(c[1] / sum(c.values()), 3)}")
        print(c.most_common(5))


        input_dim = N_spatial_nodes
        seq_len = obs_window

        lstm_model = MV_LSTM(input_dim, seq_len, hidden_units, output_size=n_classes, device=device)
        lstm_model = lstm_model.to(device)

        model_parameters = filter(lambda p: p.requires_grad, lstm_model.parameters())
        params = sum([np.prod(p.size()) for p in model_parameters])
        print(f"Number of parameters: {params}")

        today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        log_dir = f"./runs_LSTM_w={obs_window}_OAA/pos={positive_class}/{today}_lr={learning_rate}_b={batch_size}"
        check_create_folder(log_dir)

        ### TRAINING ###
        optimizer = torch.optim.Adam(lstm_model.parameters(), lr=learning_rate, weight_decay=weight_decay)
        scheduler = StepLR(optimizer, step_size=step_size, gamma=gamma_step)

        loss_criterion = nn.CrossEntropyLoss() #CELossWithSparsityRegularizer(model=GTCNN, lambda_value=lmbda)
        val_metric = None # accuracy_classification

        best_model, best_epoch = train_model_quakes(
            model=lstm_model,
            training_data=trn_data, validation_data=val_data,  # [n_samples x 1 x nodes x timesteps]
            trn_labels=trn_labels, val_labels=val_labels,  # [n_samples x spatial_nodes]
            num_epochs=num_epochs, batch_size=batch_size,
            loss_criterion=loss_criterion, optimizer=optimizer, scheduler=scheduler,
            val_metric_criterion=val_metric,
            log_dir=log_dir,
            not_learning_limit=not_learning_limit,
            show_notifications=False
        )

        print("\n\nTesting on test set")

        # Best model
        predictions = perform_chunk_predictions(best_model, tst_data, chunk_size=batch_size)
        accuracy_value = round(accuracy_classification(predictions, tst_labels).item(), 3)
        test_cm = compute_confusion_matrix(predictions, tst_labels)
        np.save(arr=test_cm, file=os.path.join(log_dir, "cm_tst_best.npy"))
        best_models_confusion_matrices.append(test_cm)
        print(f"[Best]Accuracy is: {accuracy_value * 100} \n")
        # toaster = ToastNotifier()
        # toaster.show_toast(title="Test accuracy (best)", msg=f"{accuracy_value * 100}")

        tst_accuracies_best.append(accuracy_value)
        print(f"[Best]Tst accuracies so far: {tst_accuracies_best} | mean: {np.mean(tst_accuracies_best)} | std: {np.std(tst_accuracies_best)}\n\n")

        # Last model
        checkpoint_last = torch.load(log_dir + "/last_model.pth")
        lstm_model.load_state_dict(checkpoint_last['model_state_dict'])
        lstm_model.eval()
        predictions = perform_chunk_predictions(lstm_model, tst_data, chunk_size=batch_size)
        accuracy_value = round(accuracy_classification(predictions, tst_labels).item(), 3)
        test_cm = compute_confusion_matrix(predictions, tst_labels)
        np.save(arr=test_cm, file=os.path.join(log_dir, "cm_tst_last.npy"))
        last_models_confusion_matrices.append(test_cm)
        print(f"[Last]Accuracy is: {accuracy_value * 100} \n")
        # toaster = ToastNotifier()
        # toaster.show_toast(title="Test accuracy (last)", msg=f"{accuracy_value * 100}")

        tst_accuracies_last.append(accuracy_value)
        print(f"[Last]Tst accuracies so far: {tst_accuracies_last} | mean: {np.mean(tst_accuracies_last)} | std: {np.std(tst_accuracies_last)}\n\n")

    log_dir = f"./LSTM_conf_matrices_OAA/pos={positive_class}/"
    check_create_folder(log_dir)


    sum_of_confusion_matrices_best = np.sum(np.array(best_models_confusion_matrices), axis=0)
    np.save(arr=sum_of_confusion_matrices_best, file=os.path.join(log_dir, f"sum_of_confusion_matrices_{N_ITERATIONS}_iters_best.npy"))

    sum_of_confusion_matrices_last = np.sum(np.array(last_models_confusion_matrices), axis=0)
    np.save(arr=sum_of_confusion_matrices_last, file=os.path.join(log_dir, f"sum_of_confusion_matrices_{N_ITERATIONS}_iters_last.npy"))

    print(tst_accuracies_best)
    print(np.mean(tst_accuracies_best))
    print(np.std(tst_accuracies_best))
    print("\n\n")
    print(tst_accuracies_last)
    print(np.mean(tst_accuracies_last))
    print(np.std(tst_accuracies_last))

    descr = f"Best: {tst_accuracies_best} | Mean: {np.mean(tst_accuracies_best)} | Std: {np.std(tst_accuracies_best)}" \
        f"\nLast: {tst_accuracies_last} | Mean: {np.mean(tst_accuracies_last)}| Std: {np.std(tst_accuracies_last)}"
    write_pickle(descr, os.path.join(log_dir, f"results_{N_ITERATIONS}_iters_pos={positive_class}.pickle"))

    toaster = ToastNotifier()
    toaster.show_toast(title=f"LSTM Done for class {positive_class}")

    print(positive_class)