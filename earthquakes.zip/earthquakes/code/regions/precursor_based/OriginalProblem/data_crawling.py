import datetime
import os
import time
from requests.exceptions import ConnectionError
import pandas as pd
import matplotlib.pyplot as plt
from obspy import UTCDateTime
from requests import HTTPError
from urllib3.exceptions import ProtocolError
import numpy as np
import random
from definitions import QUAKES_RAW_DATA_PATH
from earthquakes.quakes_util import quake_filename_to_UTCDateTime, string_to_UTCDateTime, timeit_context, obtain_data, \
    write_pickle, UTCDateTime_to_string, BadDataException
from utils.misc_utils import check_create_folder

NEW_DATASET_FOLDER = os.path.join(QUAKES_RAW_DATA_PATH, "new_dataset_gabriele")

quakes_df = pd.read_csv(os.path.join(NEW_DATASET_FOLDER, "final_quakes_in_bbox_balanced.csv"))
quakes_df['label'] = quakes_df['label'].astype(int)

stations_df = pd.read_csv(os.path.join(NEW_DATASET_FOLDER, "stations_in_bbox.csv"), header=None)

n_stations = stations_df.shape[0]
n_quakes = quakes_df.shape[0]

quakes_df\
    .groupby('label')\
    .size()\
    .reset_index(name='counts')\
    .sort_values('label')\
    .plot.bar(x='label', y='counts', rot=0, figsize=(10, 6))
#plt.show()




WAVE_LENGTH = 30
stations_to_query = list(stations_df[0].values)

###############################################################################################
# TUZ, TSZ, OPRZ, GRZ, BHW are giving problems
###############################################################################################

print(stations_to_query)
############################ CRAWLING ############################


# First, we check which waves we already crawled
quakes_data_folder = os.path.join(NEW_DATASET_FOLDER, f"w={WAVE_LENGTH}", "quakes_data")
quakes_failures_folder = os.path.join(NEW_DATASET_FOLDER, f"w={WAVE_LENGTH}", "quakes_failures")
check_create_folder(quakes_data_folder)
check_create_folder(quakes_failures_folder)


# year_to_crawl = 2016
# subset_df = quakes_df[pd.to_datetime(quakes_df['time']).dt.year == year_to_crawl]
subset_df = quakes_df
final_quakes_metadata = subset_df.to_dict('records')

crawled_event_ids = [file.split("_")[1].split(".")[0] for file in os.listdir(quakes_data_folder) if
                     file.endswith(".pickle")]
failed_event_ids = [file.split("_")[1].split(".")[0] for file in os.listdir(quakes_failures_folder) if
                    file.endswith(".pickle")]
# print(f"{len(crawled_event_ids)} quakes are already crawled in '{quakes_data_folder}'.")
# print(f"{len(failed_event_ids)} quakes are marked as failed in '{quakes_failures_folder}'. Please, delete them if you want to try the again.")

# final_quakes_metadata.reverse()

for idx, quake_dict in enumerate(final_quakes_metadata):


    quake_timestamp = string_to_UTCDateTime(quake_dict['time'])

    quake_event_id = quake_dict['#eventid']
    does_file_exist = quake_event_id in crawled_event_ids or quake_event_id in failed_event_ids
    if does_file_exist:
        print(f"Quake {idx} ({quake_event_id}) already crawled or failed. Continue.")
        continue

    with timeit_context('Quake retrieval'):
        try:
            print(f"\n\nCrawling quake {idx} | time: {quake_timestamp}")

            before_quake = UTCDateTime(quake_timestamp - datetime.timedelta(seconds=WAVE_LENGTH))
            after_quake = UTCDateTime(quake_timestamp + datetime.timedelta(seconds=WAVE_LENGTH))

            expected_samples = 100 * WAVE_LENGTH * 2

            # GET WAVES
            with timeit_context('Waves'):
                start = before_quake
                end = after_quake
                print(f"Expected samples: {expected_samples}")
                print(f"Start_time: {start} . End_time: {end}")
                crawled_data = obtain_data(
                    start=start, end=end,
                    stations_to_query=stations_to_query, expected_samples=expected_samples
                )

                quake_dict['data'] = crawled_data
                quake_dict['wave_length'] = WAVE_LENGTH

                write_pickle(quake_dict, f'{quakes_data_folder}/quake_{quake_dict["#eventid"]}.pickle')



        except (TypeError, BadDataException, ConnectionError, HTTPError, ProtocolError) as e:
            print(f"Quake {idx} ({quake_event_id}) failed.")
            print(e)
            print(type(e))
            now = datetime.datetime.now().isoformat().replace(":", "_").replace(".", "_")

            error_string = str(e) + "\n" + str(type(e))
            write_pickle(error_string, f'{quakes_failures_folder}/quake_{quake_dict["#eventid"]}.pickle')
