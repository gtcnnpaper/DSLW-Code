import datetime
import os
from os import path

from torch import nn
from torch.optim.lr_scheduler import StepLR

from architectures.lstm import MV_LSTM
from definitions import QUAKES_NEW_DATASET_PATH
from earthquakes.quakes_util import  process_quake_data
from prediction.pred_utils import get_device
import torch
import numpy as np

from prediction.train_utils import accuracy_classification, train_model_quakes, perform_chunk_predictions, \
    compute_confusion_matrix
from utils.misc_utils import check_create_folder

torch.cuda.current_device()
torch.set_default_tensor_type(torch.FloatTensor)
device = get_device(use_gpu=False)


N_ITERATIONS = 15
PERCENTAGE_OF_TRAINING_DATA_TO_KEEP = 1.00


num_epochs = 100
learning_rate = 0.001 # 0.0005
weight_decay = 0
batch_size = 200
not_learning_limit = 50
step_size = 100
gamma_step = 0.8

hidden_units = 8

data = np.load(path.join(QUAKES_NEW_DATASET_PATH, "data_downsampledAt100Hz.npy"))
labels = np.load(path.join(QUAKES_NEW_DATASET_PATH, "labels.npy"))
adjacency_matrix = np.load(path.join(QUAKES_NEW_DATASET_PATH, "weighted_adjacency.npy"))
adjacency_matrix = torch.from_numpy(adjacency_matrix).numpy()
data_splits = [0.6, 0.2, 0.2]
# data needs to be of shape [batch x stations x timesteps]

# 20 samples represent 10 seconds of data (it is recorded at two hertz)
SECONDS = 10
HERTZ = 100
start = int(data.shape[2]/2) - SECONDS * HERTZ
end = int(data.shape[2]/2) + 0
data = data[:, :, start:end]


tst_accuracies_best = []
tst_accuracies_last = []
best_models_confusion_matrices = []
last_models_confusion_matrices = []
for i in range(N_ITERATIONS):
    print(f"Iteration {i}")

    ############################################# DATA ########################################################################
    trn_data, trn_labels, val_data, val_labels, tst_data, tst_labels, norm_metadata = process_quake_data(
        data.copy(), labels, data_splits, normalize=True, device=device)

    N_spatial_nodes = trn_data.shape[2]
    obs_window = trn_data.shape[3]
    n_classes = len(np.unique(labels))
    assert n_classes == 45
    print(f"{N_spatial_nodes} nodes | Observation window: {obs_window}")

    trn_data = trn_data.squeeze(1).transpose(dim0=1, dim1=2)
    val_data = val_data.squeeze(1).transpose(dim0=1, dim1=2)
    tst_data = tst_data.squeeze(1).transpose(dim0=1, dim1=2)

    trn_data = trn_data[:int(PERCENTAGE_OF_TRAINING_DATA_TO_KEEP * trn_data.shape[0])]
    trn_labels = trn_labels[:int(PERCENTAGE_OF_TRAINING_DATA_TO_KEEP * trn_labels.shape[0])]
    print(f"Selecting {PERCENTAGE_OF_TRAINING_DATA_TO_KEEP * 100}% of the training set.")
    print(f"[NEW]. Trn samples: {trn_data.shape[0]} | Val samples: {val_data.shape[0]} | Tst samples: {tst_data.shape[0]}")



    ################################################################ TRAINING CODE ########################################





    input_dim = N_spatial_nodes
    seq_len = obs_window

    lstm_model = MV_LSTM(input_dim, seq_len, hidden_units, output_size=n_classes, device=device)
    lstm_model = lstm_model.to(device)

    model_parameters = filter(lambda p: p.requires_grad, lstm_model.parameters())
    params = sum([np.prod(p.size()) for p in model_parameters])
    print(f"Number of parameters: {params}")


    ### TRAINING ###
    optimizer = torch.optim.Adam(lstm_model.parameters(), lr=learning_rate, weight_decay=weight_decay)
    scheduler = StepLR(optimizer, step_size=step_size, gamma=gamma_step)

    loss_criterion = nn.CrossEntropyLoss()
    val_metric = None #accuracy_classification

    today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")


    log_dir = f"./runs_quakes_LSTM_w={obs_window}_perc={PERCENTAGE_OF_TRAINING_DATA_TO_KEEP}/{today}_lr={learning_rate}_b={batch_size}"
    check_create_folder(log_dir)


    best_model, best_epoch = train_model_quakes(
        model=lstm_model,
        training_data=trn_data, validation_data=val_data,  # [n_samples x 1 x nodes x timesteps]
        trn_labels=trn_labels, val_labels=val_labels,  # [n_samples x spatial_nodes]
        num_epochs=num_epochs, batch_size=batch_size,
        loss_criterion=loss_criterion, optimizer=optimizer, scheduler=scheduler,
        val_metric_criterion=val_metric,
        log_dir=log_dir,
        not_learning_limit=not_learning_limit,
        print_cm=False
    )

    print("\n\nTesting on test set")


    # Best model
    predictions = perform_chunk_predictions(best_model, tst_data, chunk_size=batch_size)
    accuracy_value = round(accuracy_classification(predictions, tst_labels).item(), 3)
    test_cm = compute_confusion_matrix(output=predictions, target=tst_labels, print_cm=False)
    np.save(arr=test_cm, file=os.path.join(log_dir, "cm_tst.npy"))
    best_models_confusion_matrices.append(test_cm)
    print(f"[Best]Accuracy is: {accuracy_value * 100} \n")

    tst_accuracies_best.append(accuracy_value)
    print(f"[Best]Tst accuracies so far: {tst_accuracies_best} | mean: {np.mean(tst_accuracies_best)} | std: {np.std(tst_accuracies_best)}\n\n")

    # Last model
    checkpoint_last = torch.load(log_dir + "/last_model.pth")
    lstm_model.load_state_dict(checkpoint_last['model_state_dict'])
    lstm_model.eval()
    predictions = perform_chunk_predictions(lstm_model, tst_data, chunk_size=batch_size)
    test_cm = compute_confusion_matrix(predictions, tst_labels)
    np.save(arr=test_cm, file=os.path.join(log_dir, "cm_tst_last.npy"))
    last_models_confusion_matrices.append(test_cm)
    accuracy_value = round(accuracy_classification(predictions, tst_labels).item(), 3)
    compute_confusion_matrix(predictions, tst_labels)
    print(f"[Last]Accuracy is: {accuracy_value * 100} \n")


    tst_accuracies_last.append(accuracy_value)
    print(f"[Last]Tst accuracies so far: {tst_accuracies_last} | mean: {np.mean(tst_accuracies_last)} | std: {np.std(tst_accuracies_last)}\n\n")


today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
log_dir = f"./LSTM_conf_matrices/{today}/"
check_create_folder(log_dir)
sum_of_confusion_matrices = np.sum(np.array(best_models_confusion_matrices), axis=0)
np.save(arr=sum_of_confusion_matrices, file=os.path.join(log_dir, f"sum_of_confusion_matrices_{N_ITERATIONS}_iters_best.npy"))

sum_of_confusion_matrices_last = np.sum(np.array(last_models_confusion_matrices), axis=0)
np.save(arr=sum_of_confusion_matrices_last, file=os.path.join(log_dir, f"sum_of_confusion_matrices_{N_ITERATIONS}_iters_last.npy"))

print(tst_accuracies_best)
print(np.mean(tst_accuracies_best))
print(np.std(tst_accuracies_best))
print("\n\n")
print(tst_accuracies_last)
print(np.mean(tst_accuracies_last))
print(np.std(tst_accuracies_last))
