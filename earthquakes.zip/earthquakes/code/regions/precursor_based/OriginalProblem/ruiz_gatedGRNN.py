import datetime
import os
from collections import Counter
from os import path

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.optim.lr_scheduler import StepLR
from win10toast import ToastNotifier

from architectures.space_time.grnn_ruiz.architecture import GatedGCRNNforClassification
from definitions import QUAKES_NEW_DATASET_PATH
from earthquakes.quakes_util import process_quake_data
from earthquakes.quakes_util import read_pickle
from prediction.pred_utils import get_device, get_name_string
from prediction.train_utils import train_model_quakes, accuracy_classification, perform_chunk_predictions, \
    compute_confusion_matrix
from utils.misc_utils import check_create_folder

torch.cuda.current_device()
torch.set_default_tensor_type(torch.FloatTensor)
device = get_device(use_gpu=True)



PREFIX = ""


data = np.load(path.join(QUAKES_NEW_DATASET_PATH, "data_downsampledAt2Hz.npy"))
labels = np.load(path.join(QUAKES_NEW_DATASET_PATH, "labels.npy"))
adjacency_matrix = np.load(path.join(QUAKES_NEW_DATASET_PATH, "weighted_adjacency.npy"))
adjacency_matrix = torch.from_numpy(adjacency_matrix).numpy()
data_splits = [0.6, 0.2, 0.2]



# 20 samples represent 10 seconds of data (it is recorded at two hertz)
timesteps = 20
start = int(data.shape[2]/2) - timesteps
end = int(data.shape[2]/2) + 0
data = data[:, :, start:end]



N_ITERATIONS = 15
PERCENTAGE_OF_TRAINING_DATA_TO_KEEP = 1.00

num_epochs = 50
learning_rate = 0.001# 0.0005
weight_decay = 0.0000 # 0.0005
batch_size = 128
not_learning_limit = 150
step_size = 60
gamma_step = 0.8



tst_accuracies_best = []
tst_accuracies_last = []
best_models_confusion_matrices = []
last_models_confusion_matrices = []
for i in range(N_ITERATIONS):
    print(f"Iteration {i}")

    ############################################# DATA ########################################################################
    trn_data, trn_labels, val_data, val_labels, tst_data, tst_labels, norm_metadata = process_quake_data(
        data.copy(), labels, data_splits, normalize=True, device=device)

    trn_data = trn_data[:int(PERCENTAGE_OF_TRAINING_DATA_TO_KEEP * trn_data.shape[0])]
    trn_labels = trn_labels[:int(PERCENTAGE_OF_TRAINING_DATA_TO_KEEP * trn_labels.shape[0])]
    print(f"Selecting {PERCENTAGE_OF_TRAINING_DATA_TO_KEEP * 100}% of the training set.")
    print(f"[NEW]. Trn samples: {trn_data.shape[0]} | Val samples: {val_data.shape[0]} | Tst samples: {tst_data.shape[0]}")

    N_spatial_nodes = trn_data.shape[2]
    obs_window = trn_data.shape[3]
    n_classes = len(np.unique(labels))
    assert n_classes == 45
    print(f"{N_spatial_nodes} nodes | Observation window: {obs_window} | {n_classes} classes")
    print(f"Training samples: {trn_data.shape[0]} | Validation samples: {val_data.shape[0]} | test samples: {tst_data.shape[0]}")

    ##################################################################################################################################


    # reshape input data
    # input data is of dimension [n_samples x 1 x nodes x timesteps]
    # but the GRNN wants it of dimension [# the input is of dimension: [n_samples x timesteps x 1 x numberNodes]]
    trn_data = trn_data.permute(0, 3, 1, 2)
    val_data = val_data.permute(0, 3, 1, 2)
    tst_data = tst_data.permute(0, 3, 1, 2)



    grnn_model = GatedGCRNNforClassification(
        inFeatures=1,
        stateFeatures=5, #20
        inputFilterTaps=4,
        stateFilterTaps=4,
        stateNonlinearity=nn.functional.tanh,
        outputNonlinearity=nn.ReLU,
        dimLayersMLP=[n_classes],
        GSO=adjacency_matrix,
        bias=True,
        time_gating=False,
        spatial_gating='edge'
    )
    grnn_model.to(device)
    print(grnn_model)

    model_parameters = filter(lambda p: p.requires_grad, grnn_model.parameters())
    params = sum([np.prod(p.size()) for p in model_parameters])
    print(f"Number of parameters: {params}")


    today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    log_dir = f"./runs_quakes_GRNN_w={obs_window}_{n_classes}cls/{today}_lr={learning_rate}_b={batch_size}"

    ### TRAINING ###
    optimizer = torch.optim.Adam(grnn_model.parameters(), lr=learning_rate, weight_decay=weight_decay)
    scheduler = StepLR(optimizer, step_size=step_size, gamma=gamma_step)

    loss_criterion = nn.CrossEntropyLoss()
    val_metric = None # accuracy_classification


    best_model, best_epoch = train_model_quakes(
        model=grnn_model,
        training_data=trn_data, validation_data=val_data,  # [n_samples x 1 x nodes x timesteps]
        trn_labels=trn_labels, val_labels=val_labels,  # [n_samples x spatial_nodes]
        num_epochs=num_epochs, batch_size=batch_size,
        loss_criterion=loss_criterion, optimizer=optimizer, scheduler=scheduler,
        val_metric_criterion=val_metric,
        log_dir=log_dir,
        not_learning_limit=not_learning_limit,
        show_notifications=False,
        print_cm=False
    )



    print("\n\nTesting on test set")

    # Best model
    predictions = perform_chunk_predictions(best_model, tst_data, chunk_size=batch_size)
    accuracy_value = round(accuracy_classification(predictions, tst_labels).item(), 3)
    test_cm = compute_confusion_matrix(predictions, tst_labels)
    np.save(arr=test_cm, file=os.path.join(log_dir, "cm_tst_best.npy"))
    best_models_confusion_matrices.append(test_cm)
    print(f"[Best]Accuracy is: {accuracy_value * 100} \n")
    toaster = ToastNotifier()
    toaster.show_toast(title="Test accuracy (best)", msg=f"{accuracy_value * 100}")

    tst_accuracies_best.append(accuracy_value)
    print(f"[Best]Tst accuracies so far: {tst_accuracies_best} | mean: {np.mean(tst_accuracies_best)} | std: {np.std(tst_accuracies_best)}\n\n")

    # Last model
    checkpoint_last = torch.load(log_dir + "/last_model.pth")
    grnn_model.load_state_dict(checkpoint_last['model_state_dict'])
    grnn_model.eval()
    predictions = perform_chunk_predictions(grnn_model, tst_data, chunk_size=batch_size)
    accuracy_value = round(accuracy_classification(predictions, tst_labels).item(), 3)
    test_cm = compute_confusion_matrix(predictions, tst_labels)
    np.save(arr=test_cm, file=os.path.join(log_dir, "cm_tst_last.npy"))
    last_models_confusion_matrices.append(test_cm)
    print(f"[Last]Accuracy is: {accuracy_value * 100} \n")
    toaster = ToastNotifier()
    toaster.show_toast(title="Test accuracy (last)", msg=f"{accuracy_value * 100}")

    tst_accuracies_last.append(accuracy_value)
    print(f"[Last]Tst accuracies so far: {tst_accuracies_last} | mean: {np.mean(tst_accuracies_last)} | std: {np.std(tst_accuracies_last)}\n\n")


    

today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
log_dir = f"./grnn_model_conf_matrices/{today}/"
check_create_folder(log_dir)


sum_of_confusion_matrices_best = np.sum(np.array(best_models_confusion_matrices), axis=0)
np.save(arr=sum_of_confusion_matrices_best, file=os.path.join(log_dir, f"sum_of_confusion_matrices_{N_ITERATIONS}_iters_best.npy"))

sum_of_confusion_matrices_last = np.sum(np.array(last_models_confusion_matrices), axis=0)
np.save(arr=sum_of_confusion_matrices_last, file=os.path.join(log_dir, f"sum_of_confusion_matrices_{N_ITERATIONS}_iters_last.npy"))

print(tst_accuracies_best)
print(np.mean(tst_accuracies_best))
print(np.std(tst_accuracies_best))
print("\n\n")
print(tst_accuracies_last)
print(np.mean(tst_accuracies_last))
print(np.std(tst_accuracies_last))






























