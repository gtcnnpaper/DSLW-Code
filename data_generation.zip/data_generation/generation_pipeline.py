import networkx as nx
import os
import datetime
import torch
import json

import data_generation.generation_config as data_cfg
from utils.data_utils import create_dataset, compute_total_number_data_points_src_loc, perform_split, save_split_data
from utils.graph_utils import create_connected_undirected_sbm_graph, plot_sbm_graph, compute_normalized_adjacency_matrix
from utils.misc_utils import check_create_folder

torch.set_default_dtype(torch.float64)
print(f"The sizes of the graph are {data_cfg.sizes}")
print(f"Shifts are up to {data_cfg.t_max}")
print(f"Observation windows are {data_cfg.observation_windows}")
print(f"Trn, val, test split is {data_cfg.trn_val_tst_split}")
print(f"{data_cfg.n_graphs} graphs with {data_cfg.n_splits_per_graph} splits each.\n")

date = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
dataset_folder = os.path.join(data_cfg.PATH_TO_DATASET, date + f"_overlap={data_cfg.allow_overlap_between_samples}")
check_create_folder(dataset_folder)


# Let's save the configuration used to create the dataset
with open(os.path.join(dataset_folder, "data_generation_medatada.json"), 'w') as fp:
    json.dump(data_cfg.data_generation_metadata, fp, indent=2)

for graph_idx in range(data_cfg.n_graphs):
    print(f"\nCreation of graph number {graph_idx}...")
    graph_folder = os.path.join(dataset_folder, f"graph_{graph_idx}")
    check_create_folder(graph_folder)

    sbm_graph = create_connected_undirected_sbm_graph(data_cfg.sizes, data_cfg.probs, verbose=True)
    plot_sbm_graph(sbm_graph, data_cfg.sizes, title=f"Graph {graph_idx}. Intra:{data_cfg.in_prob}. Inter: {data_cfg.between_prob}")

    gso = torch.from_numpy(compute_normalized_adjacency_matrix(sbm_graph).toarray())

    adjacency = torch.from_numpy(nx.adjacency_matrix(sbm_graph).astype(dtype='int64').toarray()).double()  # will be saved
    torch.save(adjacency, os.path.join(graph_folder, 'adj_matrix.pt'))

    for obs_window in data_cfg.observation_windows:
        print(f"\nData creation for window '{obs_window}'")

        window_folder = os.path.join(graph_folder, f"w={obs_window}")
        check_create_folder(window_folder)

        data, labels = create_dataset(data_cfg.sizes, obs_window, data_cfg.allow_overlap_between_samples, gso, data_cfg.t_max, verbose=True)
        print(f"Shape of the data: {data.shape}")

        # verify that our calculation matches our implementation
        total_number_of_datapoints_per_graph = compute_total_number_data_points_src_loc(obs_window, data_cfg.n_nodes, data_cfg.t_max, data_cfg.allow_overlap_between_samples)
        print(f"Window of '{obs_window}' --> {total_number_of_datapoints_per_graph} datapoints per graph.")
        assert labels.shape[0] == total_number_of_datapoints_per_graph
        assert data.shape[0] == total_number_of_datapoints_per_graph

        indices = list(range(data.shape[0]))  # we will need to shuffle them

        print("Performing splits")
        for split_idx in range(data_cfg.n_splits_per_graph):
            split_folder = os.path.join(window_folder, f"split_{split_idx}")
            check_create_folder(split_folder)

            trn_data, trn_labels, val_data, val_labels, tst_data, tst_labels = perform_split(indices, data, labels,
                                                                                             data_cfg.trn_val_tst_split)

            description = f"""{trn_labels.shape[0]} training\n{val_labels.shape[0]} validation\n{tst_labels.shape[0]} test"""

            with open(os.path.join(split_folder, 'descr.txt'), 'w') as file:
                file.write(description)

            save_split_data(trn_data, trn_labels,
                            val_data, val_labels,
                            tst_data, tst_labels,
                            split_folder)
        print(description)





