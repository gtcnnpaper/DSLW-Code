import os

from utils.misc_utils import build_probability_matrix

sizes = [20, 20, 20, 20, 20]                    # sizes for each community
in_prob = 0.8                     # probability of a link between two nodes in the same community
between_prob = 0.1                 # probability of a link between nodes in different communities
t_max = 25                          # Maximum number of diffusion times (W^t for t < t_max)

n_nodes = sum(sizes)                 # Number of nodes
n_communities = len(sizes)               # Number of classes (i.e. number of communities)
n_graphs = 5                       # How many graphs to generate
n_splits_per_graph = 5                        # how many splits per realization
trn_val_tst_split = [0.8, 0.2, 0]           # train, validation, test

observation_windows = [1, 2, 3]     # how many subsequent shifted graph signals form a single training point
allow_overlap_between_samples = False                     # whether or not observation windows should overlap

probs = build_probability_matrix(n_communities, in_prob, between_prob)

PATH_TO_DATASET = os.path.join("../", "datasets")

data_generation_metadata = {
    "sizes": sizes,
    "in_prob": in_prob,
    "between_prob": between_prob,
    "t_max": t_max,
    "n_nodes": n_nodes,
    "n_communities": n_communities,
    "n_graphs": n_graphs,
    "n_splits_per_graph": n_splits_per_graph,
    "trn_val_tst_split": trn_val_tst_split,
    "observation_windows": observation_windows,
    "allow_overlap_between_samples": allow_overlap_between_samples
}