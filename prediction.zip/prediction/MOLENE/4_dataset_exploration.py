import os
import pickle

import pandas as pd
import numpy as np
import torch
import matplotlib.pyplot as plt
from pygsp import graphs, plotting

from utils.misc_utils import check_create_folder

plotting.BACKEND = 'matplotlib'
plt.rcParams['figure.figsize'] = (10, 5)

torch.set_default_dtype(torch.float64)

dataset_path = r"./dataset/processed/"
sensor_data_path = dataset_path + "sensor_data_filtered.csv"
stations_metadata_path = dataset_path + "weather_stations_filtered.csv"
weighted_adjacency_path = dataset_path + "weighted_adjacency.npy"
pickle_dataset_path = dataset_path + "dataset_w=4_steps=[1, 2, 3, 4, 5]_splits=[0.35, 0.15, 0.5].pickle"
in_sample_means_dict_path = dataset_path + "in_sample_means_0.5.pickle"
figures_path = dataset_path + "../figures"

check_create_folder(figures_path)

weighted_adjacency = np.load(weighted_adjacency_path)
with open(pickle_dataset_path, 'rb') as handle:
    dataset = pickle.load(handle)
with open(in_sample_means_dict_path, 'rb') as handle:
    in_sample_means = pickle.load(handle)
stations_metadata = pd.read_csv(stations_metadata_path)
station_numbers = list(stations_metadata["Numéro"])
station_names = list(stations_metadata["Nom"])
steps_ahead = [k for k in dataset.keys() if type(k) == int]
graph_signals = dataset['all']
coordinates = stations_metadata[['Lambert II X', ' Lambert II Y']].to_numpy()  # [stations x 2]
assert coordinates.shape == (32, 2)


GRAPH = False
TIMESERIES = True
DISTRIBUTIONS = False

# Timeseries visualization
n_trn_samples = dataset['metadata']['trn_timesteps']
n_val_samples = dataset['metadata']['val_timesteps']
n_tst_samples = dataset['metadata']['tst_timesteps']
assert sum([n_trn_samples, n_val_samples, n_tst_samples]) == 744

graph_signals_with_mean_restored = []
for station_idx in range(graph_signals.shape[1]):
    station_num = station_numbers[station_idx]
    graph_signals_with_mean_restored.append(graph_signals[:, station_idx] + in_sample_means[station_num])
graph_signals_with_mean_restored = np.stack(graph_signals_with_mean_restored, axis=1)

# stations = list(stations_metadata["Numéro"])
for station_idx in range(len(station_numbers)):  # Elvin: 9
    station_num = station_numbers[station_idx]
    station_data = graph_signals[:, station_idx]
    station_data_mean_added = graph_signals_with_mean_restored[:, station_idx]

    trn_indices = range(n_trn_samples)
    val_indices = range(n_trn_samples, n_trn_samples+n_val_samples)
    tst_indices = range(n_trn_samples+n_val_samples, 744)

    if TIMESERIES:
        timeseries_folder = os.path.join(figures_path, "timeseries")
        check_create_folder(timeseries_folder)
        _, ax = plt.subplots(figsize=(18, 6))
        ax.plot(range(len(station_data_mean_added)), station_data_mean_added, color='b')

        title = f"Station {station_idx}: {station_names[station_idx]} ({station_num})"
        plt.xlabel("Time (Hours)", fontsize=20)
        plt.ylabel("Temperature (Kelvin degrees)", fontsize=20)
        plt.xticks(fontsize=17)
        plt.yticks(fontsize=17)
        # plt.title(title)
        plt.tight_layout()

        plt.savefig(os.path.join(timeseries_folder, f"station={station_idx}({station_num})_{station_names[station_idx]}.png"))
        plt.clf()

        # _, ax = plt.subplots(figsize=(15, 6))
        # ax.plot(trn_indices, station_data_mean_added[trn_indices], color='b', label="Training")
        # ax.plot(val_indices, station_data_mean_added[val_indices], color='r', label="Validation")
        # ax.plot(tst_indices, station_data_mean_added[tst_indices], color='g', label="Test")
        #
        # plt.axvline(x=n_trn_samples, c='r', linestyle=':')
        # plt.axvline(x=n_trn_samples + n_val_samples, c='r', linestyle=':')
        #
        #
        #
        # title = f"{station_idx}: {station_names[station_idx]} ({station_num}))"
        # plt.ylabel("Temperature (Kelvin degrees)")
        # plt.title(title)
        # plt.legend()
        # plt.tight_layout()
        # plt.show()


        # _, ax = plt.subplots(figsize=(15, 6))
        # ax.plot(trn_indices, station_data[trn_indices], color='b', label="trn")
        # ax.plot(val_indices, station_data[val_indices], color='r', label="val")
        # ax.plot(tst_indices, station_data[tst_indices], color='g', label="tst")
        #
        # plt.axvline(x=n_trn_samples, c='r', linestyle=':')
        # plt.axvline(x=n_trn_samples + n_val_samples, c='r', linestyle=':')
        #
        # title = f"{station_idx}: {station_names[station_idx]} ({station_num}) (in-sample mean({in_sample_means[station_num]}) removed)"
        # plt.ylabel("Temperature (Kelvin degrees)")
        # plt.title(title)
        # plt.legend()
        # plt.tight_layout()
        # plt.show()


        # _, ax = plt.subplots(figsize=(15, 6))
        # ax.plot(trn_indices, station_data_mean_added[trn_indices] - 273.15, color='b', label="trn")
        # ax.plot(val_indices, station_data_mean_added[val_indices] - 273.15, color='r', label="val")
        # ax.plot(tst_indices, station_data_mean_added[tst_indices] - 273.15, color='g', label="tst")
        #
        # plt.axvline(x=n_trn_samples, c='r', linestyle=':')
        # plt.axvline(x=n_trn_samples + n_val_samples, c='r', linestyle=':')
        #
        # title = f"{station_idx}: {station_names[station_idx]} ({station_num}) (in-sample mean({in_sample_means[station_num]}) removed)"
        # plt.ylabel("Temperature (Celsius degrees)")
        # plt.ylim(top=15)  # adjust the top leaving bottom unchanged
        # plt.ylim(bottom=0)
        # plt.title(title)
        # plt.legend()
        # plt.tight_layout()
        # plt.show()


    if DISTRIBUTIONS:
        distributions_folder = os.path.join(figures_path, "distributions")
        check_create_folder(distributions_folder)

        pd.Series(station_data[trn_indices]).plot(kind='kde', label="train")
        pd.Series(station_data[val_indices]).plot(kind='kde', label="val")
        pd.Series(station_data[tst_indices]).plot(kind='kde', label="test")
        plt.legend()
        title = f"{station_idx}:{station_names[station_idx]}({station_num})"
        plt.title(title)
        plt.tight_layout()
        plt.savefig(os.path.join(distributions_folder, f"station={station_idx}({station_num})_{station_names[station_idx]}.png"))
        plt.clf()



if GRAPH:
    # Graph visualization
    G = graphs.Graph(weighted_adjacency)
    G.set_coordinates(coordinates)


    day = 8
    hour = 19

    sample_idx = day * 24 + hour
    fig = plt.figure(figsize=(13, 10))
    for i in range(4):
        ax = fig.add_subplot(2, 2, i+1)
        graph_signal = graph_signals_with_mean_restored[sample_idx + i][:] - 273.15
        title = f"Day: {day} | Hour: {hour} --> Observation {i + 1})"
        limits = [3, 10]
        plotting.plot_signal(G, graph_signal, limits=limits, highlight=[9], ax=ax, plot_name=title, vertex_size=250)

    plt.tight_layout()
    plt.show()



