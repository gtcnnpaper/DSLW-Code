import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from pygsp import graphs, plotting
plotting.BACKEND = 'matplotlib'
plt.rcParams['figure.figsize'] = (10, 5)
import sys
np.set_printoptions(threshold=sys.maxsize)
from prediction.pred_utils import weight_MOLENE_dataset


dataset_path = r"./dataset/processed/"
sensor_data_path = dataset_path + "sensor_data_filtered.csv"
stations_metadata_path = dataset_path + "weather_stations_filtered.csv"
weighted_adjacency_path = dataset_path + "weighted_adjacency.npy"




stations_metadata_df = pd.read_csv(stations_metadata_path)  # Where we get the coordinates information
coordinates = stations_metadata_df[['Lambert II X', ' Lambert II Y', 'Altitude']].to_numpy() # [stations x 3]
coordinates[:, 0] = coordinates[:, 0] - np.mean(coordinates[:, 0])
coordinates[:, 1] = coordinates[:, 1] - np.mean(coordinates[:, 1])
coordinates[:, 2] = coordinates[:, 2] - np.mean(coordinates[:, 2])

assert coordinates.shape == (32, 3)




# Let's look at the NN graph
NN = 10
G = graphs.NNGraph(coordinates, k=NN)
G.set_coordinates(coordinates[:, :-1])
_, axes = plt.subplots(1, 2)
_ = axes[0].spy(G.W, markersize=5)
G.plot(ax=axes[1])
plt.show()



CUSTOM_WEIGHTING = False
# Let's weight the edges by following the approach of Elvin's paper
if CUSTOM_WEIGHTING:
    weights_kernel = weight_MOLENE_dataset(coordinates, G.W.todense(), n_decimals=5)
else:
    # the default similarity weighting kernel is Gaussian.
    weights_kernel = G.W.todense().round(5)

# Let's replot, just to be sure we didn't make a mess
weighted_G = graphs.Graph(weights_kernel)
weighted_G.set_coordinates(coordinates[:, :-1])

_, axes = plt.subplots(1, 2)
_ = axes[0].spy(weighted_G.W, markersize=5)
weighted_G.plot(ax=axes[1])
plt.show()


# Let's save the obtained weighted adjacency matrix
np.save(file=weighted_adjacency_path, arr=weights_kernel)
assert (np.load(file=weighted_adjacency_path) == weights_kernel).all()


# How we converted the weights
for i in range(weights_kernel.shape[0]):
    for j in range(weights_kernel.shape[1]):
        print(f"{G.W[i, j]} --> {weighted_G.W[i, j]}")
