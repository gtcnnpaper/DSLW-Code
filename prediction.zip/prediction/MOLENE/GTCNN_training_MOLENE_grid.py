import datetime
import numpy as np
from itertools import product
import torch
from torch.optim.lr_scheduler import ReduceLROnPlateau

from architectures.space_time.parametric_pooling_net_ordering import ParametricNetWithPoolingOrdered
from prediction.train_utils import train_model_regression
from prediction.evaluation import rNMSELoss, MSELossWithSparsityRegularizer, compute_iteration_rNMSE
from prediction.pred_utils import get_device, transform_data_to_all_steps_prediction, get_name_string, get_dataset, \
    get_MOLENE_dataset

torch.cuda.current_device()



# torch.manual_seed(123)
# np.random.seed(123)
# random.seed(123)

device = get_device(use_gpu=True)





ds_folder = "../"
splits = [0.35, 0.15, 0.5]
obs_window = 4

data, steps_ahead, weighted_adjacency = get_MOLENE_dataset(
    ds_folder,
    splits=splits,
    obs_window=obs_window
)
N_spatial_nodes = weighted_adjacency.shape[0]
print(f"{N_spatial_nodes} nodes - {obs_window} observed timesteps - steps ahead: {steps_ahead}")


# Get data (We do not need test data/labels here)
trn_data, val_data, tst_data, trn_labels, val_labels, tst_labels = transform_data_to_all_steps_prediction(data, node_first=True, device=device)

trn_data = trn_data.float()
val_data = val_data.float()
tst_data = tst_data.float()
trn_labels = trn_labels.float()
val_labels = val_labels.float()
tst_labels = tst_labels.float()

# obtain one-step labels for the training
one_step_trn_labels = trn_labels[:, 0, :]  # [batch x step-ahead x nodes]
one_step_val_labels = val_labels[:, 0, :]
print(one_step_trn_labels.shape, one_step_val_labels.shape)



num_epochs = 1200 # 6000
learning_rates = [0.001] # 0.0005
weight_decays = [0]  # , 0.00001, 0]
batch_sizes = [128]
patience = 500
factor = 0.95

not_learning_limit = 700

perc_nodes_1 = [0.8]
perc_nodes_2 = [0.5]


n_features_1 = [8]
n_features_2 = [12]

taps = [
    [2, 2]
]

lambdas = [0] #, 0.00025, 0.0005, 0.001, 0.005, 0.01, 0.05]

time_pooling_ratios = [
    [2, 2]
]

p_reaches = [
    [1, 1],
    #[2, 2]
]

cyclics = [True]
time_directness = [True]


for model_number, \
    (learning_rate, batch_size,
     nodes_1, nodes_2,
     n_feat_1, n_feat_2,
     tap_values,
     t_pool,
     w_decay,
     cyclic,
     lambda_reg,
     time_directed,
     p_reach) in \
        enumerate(product(learning_rates, batch_sizes,
                          perc_nodes_1, perc_nodes_2,
                          n_features_1, n_features_2,
                          taps,
                          time_pooling_ratios,
                          weight_decays,
                          cyclics,
                          lambdas,
                          time_directness,
                          p_reaches)):


    # if model_number <= 236:
    #     continue

    print(f"\n\n\nStarting new training (number: {model_number}) --> "
          f"lr: {learning_rate} | "
          f"batch_size: {batch_size} | "
          f"perc_nodes_1: {nodes_1} | "
          f"perc_nodes_1: {nodes_2} | "
          f"n_feat_1: {n_feat_1} | "
          f"n_feat_2: {n_feat_2} | "
          f"time_pooling_ratios: {t_pool} | "
          f"weight_decay: {w_decay} | "
          f"cyclic: {cyclic} | "
          f"lambda: {lambda_reg} | "
          f"time directed: {time_directed}")

    # GTCNN
    feat_per_layer = [1, n_feat_1, n_feat_2]
    taps_per_layer = tap_values
    active_nodes_per_timestep_per_layer = [
        N_spatial_nodes,
        int(N_spatial_nodes * nodes_1),
        int(N_spatial_nodes * nodes_2)]
    time_pooling_ratio_per_layer = t_pool
    pool_reach_per_layer = p_reach

    # feat_per_layer = [1, 4, 4, 4]
    # taps_per_layer = [2, 2, 2]
    # active_nodes_per_timestep_per_layer = [
    #     N_spatial_nodes,
    #     N_spatial_nodes,
    #     int(N_spatial_nodes * 0.8),
    #     int(N_spatial_nodes * 0.8)]
    # time_pooling_ratio_per_layer = [1, 1, 4]
    # pool_reach_per_layer = [1, 1, 1]

    one_step_gtcnn = ParametricNetWithPoolingOrdered(
        window=obs_window,
        cyclic_time_graph=cyclic,
        time_directed=time_directed,
        S_spatial=weighted_adjacency,
        n_feat_per_layer=feat_per_layer,
        n_taps_per_layer=taps_per_layer,
        n_active_nodes_per_timestep_per_layer=active_nodes_per_timestep_per_layer,
        time_pooling_ratio_per_layer=time_pooling_ratio_per_layer,
        pool_reach_per_layer=pool_reach_per_layer,
        output_dim=N_spatial_nodes,
        device=device)
    one_step_gtcnn.to(device)
    print(one_step_gtcnn)

    model_parameters = filter(lambda p: p.requires_grad, one_step_gtcnn.parameters())
    params = sum([np.prod(p.size()) for p in model_parameters])
    print(f"Number of parameters: {params}")

    today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    name_string = get_name_string(
        obs_window,
        feat_per_layer, taps_per_layer, time_pooling_ratio_per_layer,
        pool_reach_per_layer, active_nodes_per_timestep_per_layer,
        w_decay, cyclic, lambda_reg, time_directed
    )
    log_dir = f"./runs_MOLENE_w={obs_window}/{today}_lr={learning_rate}_b={batch_size}_{name_string}"

    ### TRAINING ###
    loss_criterion = torch.nn.MSELoss() # MSELossWithSparsityRegularizer(one_step_gtcnn, lambda_reg)

    val_metric = None #rNMSELoss()

    optimizer = torch.optim.Adam(one_step_gtcnn.parameters(), lr=learning_rate, weight_decay=w_decay)
    scheduler = ReduceLROnPlateau(optimizer, 'min', patience=patience, factor=factor)

    train_model_regression(
        model=one_step_gtcnn,
        training_data=trn_data, validation_data=val_data,  # [n_samples x 1 x nodes x timesteps]
        single_step_trn_labels=one_step_trn_labels, single_step_val_labels=one_step_val_labels,  # [n_samples x spatial_nodes]
        num_epochs=num_epochs, batch_size=batch_size,
        loss_criterion=loss_criterion, optimizer=optimizer, scheduler=scheduler,
        val_metric_criterion=val_metric,
        log_dir=log_dir,
        not_learning_limit=not_learning_limit
    )


    rNMSE_dict, predictions_dict = compute_iteration_rNMSE(one_step_gtcnn, steps_ahead, tst_data, tst_labels,
                                                           device, verbose=False)

    results = [round(l.item(), 4) for l in list(rNMSE_dict.values())]
    print(results)
