import pickle

import pandas as pd
import numpy as np


in_sample = 0.5


dataset_path = r"./dataset/original/"
new_dataset_path = r"./dataset/processed/"
sensor_data_original_path = dataset_path + "aggregated_data.csv"
stations_metadata_path = dataset_path + "weather_stations.csv"
filtered_sensor_data_path = new_dataset_path + "sensor_data_filtered.csv"
filtered_sensor_data_no_insample_mean_path = new_dataset_path + f"sensor_data_filtered_no_means_{in_sample}.csv"
filtered_stations_metadata_path = new_dataset_path + "weather_stations_filtered.csv"
in_sample_means_dict_path = new_dataset_path + f"in_sample_means_{in_sample}.pickle"



# preprocessing
sensor_data = pd.read_csv(sensor_data_original_path, index_col='date', parse_dates=True)
sensor_data = sensor_data[['numer_sta', 't']]

# Let's replace the 'mq' (not available) values with NaNs
sensor_data = sensor_data.replace("mq", np.nan)

# Let's convert the temperature from Kelvin to Celsius
# sensor_data['t'] = sensor_data['t'].astype(float) - 273.15

sensor_data['t'] = sensor_data['t'].astype(float)
sensor_data = sensor_data.round({'t': 3})



# Find the good stations: We search for stations with full data (744 points)
good_stations = []
grouped = sensor_data.groupby('numer_sta')
for station_number, station_df in grouped:
    n_values_for_station = station_df.shape[0]
    n_missing_values_for_station = station_df['t'].isna().sum()

    if n_values_for_station == 744 and n_missing_values_for_station == 0:
        good_stations.append(station_number)
print(f"{len(good_stations)} stations with 744 values")


# Just a check
sensor_data_full = sensor_data[sensor_data['numer_sta'].isin(good_stations)]
grouped = sensor_data_full.groupby('numer_sta')
for _, station_df in grouped:
    n_values_for_station = station_df.shape[0]
    n_missing_values_for_station = station_df['t'].isna().sum()
    assert n_values_for_station == 744
    assert n_missing_values_for_station == 0






# Now we load the metadata of the stations
stations_metadata_df = pd.read_csv(stations_metadata_path)  # Where we get the coordinates information

# We are interested in the intersection between the stations where we have full data (744 points)
# and the stations for which we have geographic coordinates
stations_metadata_filtered = stations_metadata_df[stations_metadata_df['Numéro'].isin(good_stations)]
stations_metadata_filtered = stations_metadata_filtered.sort_values(by=['Numéro'])
final_stations = list(stations_metadata_filtered['Numéro'])
print(f"{len(final_stations)} available stations with position and sensor data.")







# Now that we have the stations for which we have both full data (744 datapoints) and geographic coordinates,
# we can save the two filtered files.
sensor_data_filtered = sensor_data_full[sensor_data_full['numer_sta'].isin(final_stations)]
assert sensor_data_filtered.shape[0] == len(final_stations)*744

sensor_data_filtered.to_csv(filtered_sensor_data_path)
stations_metadata_filtered.to_csv(filtered_stations_metadata_path)


# Section to remove the in-sample mean from the data
# the in-sample mean is removed from EACH station.


in_sample_means = {}
grouped = sensor_data_filtered.groupby('numer_sta')
for station_num, station_df in grouped:
    last_in_sample_index = int(len(station_df.index) * in_sample)
    in_sample_values = station_df['t'].values[:last_in_sample_index]
    in_sample_mean = round(np.mean(in_sample_values), 4)

    print(station_num, in_sample_values.shape, in_sample_mean)
    in_sample_means[station_num] = in_sample_mean



sensor_data_filtered_no_mean = sensor_data_filtered.copy()
sensor_data_filtered_no_mean['t'] = sensor_data_filtered_no_mean.apply(lambda row: row['t'] - in_sample_means[row['numer_sta']], axis=1)


grouped = sensor_data_filtered_no_mean.groupby('numer_sta')
for station_num, station_df in grouped:
    last_in_sample_index = int(len(station_df.index) * in_sample)
    in_sample_values = station_df['t'].values[:last_in_sample_index]
    in_sample_mean = round(np.mean(in_sample_values), 4)
    all_mean = np.mean(station_df['t'].values)

    print(station_num, all_mean)
    assert abs(in_sample_mean) == 0



sensor_data_filtered_no_mean.to_csv(filtered_sensor_data_no_insample_mean_path)

with open(in_sample_means_dict_path, 'wb') as handle:
    pickle.dump(in_sample_means, handle, protocol=pickle.HIGHEST_PROTOCOL)

with open(in_sample_means_dict_path, 'rb') as handle:
    dt = pickle.load(handle)
    assert dt == in_sample_means

print(in_sample_means)

print("DONE.")

