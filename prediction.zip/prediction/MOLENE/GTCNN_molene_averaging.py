import datetime
import json

import numpy as np
from itertools import product
import torch
from torch.optim.lr_scheduler import ReduceLROnPlateau

from architectures.space_time.parametric_pooling_net_ordering import ParametricNetWithPoolingOrdered
from prediction.train_utils import train_model_regression
from prediction.evaluation import rNMSELoss, MSELossWithSparsityRegularizer, compute_iteration_rNMSE
from prediction.pred_utils import get_device, transform_data_to_all_steps_prediction, get_name_string, get_dataset, \
    get_MOLENE_dataset

torch.cuda.current_device()



# torch.manual_seed(123)
# np.random.seed(123)
# random.seed(123)

device = get_device(use_gpu=True)





ds_folder = "../"
splits = [0.35, 0.15, 0.5]
obs_window = 4

data, steps_ahead, weighted_adjacency = get_MOLENE_dataset(
    ds_folder,
    splits=splits,
    obs_window=obs_window
)
N_spatial_nodes = weighted_adjacency.shape[0]
print(f"{N_spatial_nodes} nodes - {obs_window} observed timesteps - steps ahead: {steps_ahead}")


# Get data (We do not need test data/labels here)
trn_data, val_data, tst_data, trn_labels, val_labels, tst_labels = transform_data_to_all_steps_prediction(data, node_first=True, device=device)

trn_data = trn_data.float()
val_data = val_data.float()
tst_data = tst_data.float()
trn_labels = trn_labels.float()
val_labels = val_labels.float()
tst_labels = tst_labels.float()

# obtain one-step labels for the training
one_step_trn_labels = trn_labels[:, 0, :]  # [batch x step-ahead x nodes]
one_step_val_labels = val_labels[:, 0, :]
print(one_step_trn_labels.shape, one_step_val_labels.shape)

today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")

N_ITERATIONS = 10
num_epochs = 1200


learning_rate = 0.001
weight_decay = 0
batch_size = 64
patience = 150
factor = 0.9
lambda_value = 0.00025 # 0

not_learning_limit = 300

perc_nodes_1 = 0.8
perc_nodes_2 = 0.5
n_features_1 = 10  #8
n_features_2 = 12  #12
taps = [2, 2]
time_pooling_ratios = [2, 2] #[2, 2]
p_reaches = [1, 1]
cyclic = True
time_directed = True



# GTCNN
feat_per_layer = [1, n_features_1, n_features_2]
taps_per_layer = taps
active_nodes_per_timestep_per_layer = [
    N_spatial_nodes,
    int(N_spatial_nodes * perc_nodes_1),
    int(N_spatial_nodes * perc_nodes_2)]
time_pooling_ratio_per_layer = time_pooling_ratios
pool_reach_per_layer = p_reaches


res_dict = {
            'lr': learning_rate,
            'results': []
        }

for i in range(N_ITERATIONS):

    one_step_gtcnn = ParametricNetWithPoolingOrdered(
        window=obs_window,
        cyclic_time_graph=cyclic,
        time_directed=time_directed,
        S_spatial=weighted_adjacency,
        n_feat_per_layer=feat_per_layer,
        n_taps_per_layer=taps_per_layer,
        n_active_nodes_per_timestep_per_layer=active_nodes_per_timestep_per_layer,
        time_pooling_ratio_per_layer=time_pooling_ratio_per_layer,
        pool_reach_per_layer=pool_reach_per_layer,
        output_dim=N_spatial_nodes,
        device=device)
    one_step_gtcnn.to(device)
    print(one_step_gtcnn)

    model_parameters = filter(lambda p: p.requires_grad, one_step_gtcnn.parameters())
    params = sum([np.prod(p.size()) for p in model_parameters])
    print(f"Number of parameters: {params}")


    name_string = get_name_string(
        obs_window,
        feat_per_layer, taps_per_layer, time_pooling_ratio_per_layer,
        pool_reach_per_layer, active_nodes_per_timestep_per_layer,
        weight_decay, cyclic, lambda_value, time_directed
    )
    log_dir = f"./runs_MOLENE_w={obs_window}/{today}_lr={learning_rate}_b={batch_size}_{name_string}"

    ### TRAINING ###
    loss_criterion = MSELossWithSparsityRegularizer(one_step_gtcnn, lambda_value) #torch.nn.MSELoss() #
    #torch.nn.MSELoss()

    val_metric = rNMSELoss()

    optimizer = torch.optim.Adam(one_step_gtcnn.parameters(), lr=learning_rate, weight_decay=weight_decay)
    scheduler = ReduceLROnPlateau(optimizer, 'min', patience=patience, factor=factor)

    best_model, best_epoch = train_model_regression(
        model=one_step_gtcnn,
        training_data=trn_data, validation_data=val_data,  # [n_samples x 1 x nodes x timesteps]
        single_step_trn_labels=one_step_trn_labels, single_step_val_labels=one_step_val_labels,  # [n_samples x spatial_nodes]
        num_epochs=num_epochs, batch_size=batch_size,
        loss_criterion=loss_criterion, optimizer=optimizer, scheduler=scheduler,
        val_metric_criterion=val_metric,
        log_dir=log_dir,
        not_learning_limit=not_learning_limit
    )


    rNMSE_dict, predictions_dict = compute_iteration_rNMSE(best_model, steps_ahead, tst_data, tst_labels,
                                                           device, verbose=False)

    res_dict['results'].append([round(l.item(), 4) for l in list(rNMSE_dict.values())])

    means = [round(el, 4) for el in np.average(res_dict['results'], axis=0)]
    stds = [round(el, 4) for el in np.std(res_dict['results'], axis=0)]
    res_dict['final_res'] = {
        'avg': means,
        'std': stds
    }

    with open(log_dir + '/results.json', 'w', encoding='utf-8') as f:
        json.dump(res_dict, f, ensure_ascii=False, indent=4)

    print(res_dict['results'])


print(res_dict['results'])
means = [round(el, 4) for el in np.average(res_dict['results'], axis=0)]
stds = [round(el, 4) for el in np.std(res_dict['results'], axis=0)]
print(means)
print(stds)

res_dict['final_res'] = {
    'avg': means,
    'std': stds
}
with open(log_dir + '/results.json', 'w', encoding='utf-8') as f:
    json.dump(res_dict, f, ensure_ascii=False, indent=4)