import scipy.io
import numpy as np


mat = scipy.io.loadmat("C:\\Users\\gabri\\Desktop\\elvin_errors\\e_MSE_steps_molene_newerror.mat")

err_gp_var = mat['rNMSE_cgpvar']
err_g_varma = mat['rNMSE_jc']

print()