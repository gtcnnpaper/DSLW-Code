import scipy.io
import numpy as np


mat = scipy.io.loadmat("C:\\Users\\gabri\\Desktop\\grasp_molene_data.mat")
# np.save(file="C:\\Users\\gabri\\Desktop\\NOA_109_original_adj.npy", arr=mat['m_adjacency'])
# np.save(file="C:\\Users\\gabri\\Desktop\\NOA_109_data.npy", arr=mat['m_temperatureTimeSeries'])
# adj = np.load(file="C:\\Users\\gabri\\Desktop\\NOA_109_original_adj.npy")
# timeseries = np.load(file="C:\\Users\\gabri\\Desktop\\NOA_109_data.npy")



print()