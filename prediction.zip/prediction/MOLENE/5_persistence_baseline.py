# All the baselines are tested on permuted data, as it should not change the results.
import pickle
import numpy as np
import torch

from prediction.evaluation import rNMSE
from prediction.persistence import persistence_prediction
from utils.graph_utils import permutation_by_degree

dataset_path = r"./dataset/processed/"
weighted_adjacency_path = dataset_path + "weighted_adjacency.npy"
pickle_dataset_path = dataset_path + "dataset_w=4_steps=[1, 2, 3, 4, 5]_splits=[0.35, 0.15, 0.5].pickle"

with open(pickle_dataset_path, 'rb') as handle:
    data = pickle.load(handle)
weighted_adjacency = np.load(file=weighted_adjacency_path)
perm_weighted_adj, order = permutation_by_degree(weighted_adjacency)
N_spatial_nodes = perm_weighted_adj.shape[0]
observation_window = data[1]['trn']['data'].shape[1]
steps_ahead = [k for k in data.keys() if type(k) == int]
print(f"{N_spatial_nodes} nodes - {observation_window} observed timesteps - steps ahead: {steps_ahead}")



trn_persistence_rNMSE_dict = {}
val_persistence_rNMSE_dict = {}
tst_persistence_rNMSE_dict = {}
for step in steps_ahead:
    dataset_for_step = data[step]

    trn_data = torch.from_numpy(dataset_for_step['trn']['data'])[:, :, order]
    trn_labels = torch.from_numpy(dataset_for_step['trn']['labels'])[:, order]
    predictions_for_step_trn = persistence_prediction(trn_data)
    trn_rNMSE_for_step = rNMSE(trn_labels, predictions_for_step_trn)
    trn_persistence_rNMSE_dict[step] = trn_rNMSE_for_step

    val_data = torch.from_numpy(dataset_for_step['val']['data'])[:, :, order]
    val_labels = torch.from_numpy(dataset_for_step['val']['labels'])[:, order]
    predictions_for_step_val = persistence_prediction(val_data)
    val_rNMSE_for_step = rNMSE(val_labels, predictions_for_step_val)
    val_persistence_rNMSE_dict[step] = val_rNMSE_for_step

    tst_data = torch.from_numpy(dataset_for_step['tst']['data'])[:, :, order]
    tst_labels = torch.from_numpy(dataset_for_step['tst']['labels'])[:, order]
    predictions_for_step_tst = persistence_prediction(tst_data)
    tst_rNMSE_for_step = rNMSE(tst_labels, predictions_for_step_tst)
    tst_persistence_rNMSE_dict[step] = tst_rNMSE_for_step


trn_persistence_rnmses = list(trn_persistence_rNMSE_dict.values())
val_persistence_rnmses = list(val_persistence_rNMSE_dict.values())
tst_persistence_rnmses = list(tst_persistence_rNMSE_dict.values())

print(f"Persistence baseline on trn: {trn_persistence_rnmses}. Avg: {round(np.average(trn_persistence_rnmses), 3)}")
print(f"Persistence baseline on val: {val_persistence_rnmses}. Avg: {round(np.average(val_persistence_rnmses), 3)}")
print(f"Persistence baseline on tst: {tst_persistence_rnmses}. Avg: {round(np.average(tst_persistence_rnmses), 3)}")