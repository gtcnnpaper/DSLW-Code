# All the baselines are tested on permuted data, as it should not change the results.

import pickle
import random

import numpy as np
import torch
import torch.nn as nn
torch.set_default_dtype(torch.float64)

#
# torch.manual_seed(123)
# np.random.seed(123)
# random.seed(123)

from prediction.pred_utils import get_device, transform_data_to_all_steps_prediction, \
    convert_data_to_graph_time_pr_graph
from prediction.evaluation import compute_iteration_rNMSE
from utils.graph_utils import permutation_by_degree

device = get_device()

dataset_path = r"../../prediction/MOLENE/dataset/processed/"
weighted_adjacency_path = dataset_path + "weighted_adjacency.npy"
pickle_dataset_path = dataset_path + "dataset_no_insample_mean.pickle"

with open(pickle_dataset_path, 'rb') as handle:
    data = pickle.load(handle)
weighted_adjacency = np.load(file=weighted_adjacency_path)
perm_weighted_adj, order = permutation_by_degree(weighted_adjacency)
del weighted_adjacency
N_spatial_nodes = perm_weighted_adj.shape[0]
observation_window = data[1]['trn']['data'].shape[1]
steps_ahead = [k for k in data.keys() if type(k) == int]
print(f"{N_spatial_nodes} nodes - {observation_window} observed timesteps - steps ahead: {steps_ahead}")







trn_data, val_data, tst_data, trn_labels, val_labels, tst_labels = transform_data_to_all_steps_prediction(data)
trn_data = trn_data[:, :, order]
val_data = val_data[:, :, order]
tst_data = tst_data[:, :, order]
trn_labels = trn_labels[:, :, order]
val_labels = val_labels[:, :, order]
tst_labels = tst_labels[:, :, order]

# obtain flattened labels
trn_labels_flat = trn_labels.reshape(trn_labels.shape[0], -1)
val_labels_flat = val_labels.reshape(val_labels.shape[0], -1)
tst_labels_flat = tst_labels.reshape(tst_labels.shape[0], -1)
print(trn_labels_flat.shape, val_labels_flat.shape, tst_labels_flat.shape)

one_step_trn_labels = trn_labels[:, 0, :]
one_step_val_labels = val_labels[:, 0, :]
one_step_tst_labels = tst_labels[:, 0, :]
print(one_step_trn_labels.shape, one_step_val_labels.shape, one_step_tst_labels.shape)

# convert time-varying data to graph-time product graph
gt_trn_data = convert_data_to_graph_time_pr_graph(trn_data).squeeze(1)
gt_val_data = convert_data_to_graph_time_pr_graph(val_data).squeeze(1)
gt_tst_data = convert_data_to_graph_time_pr_graph(tst_data).squeeze(1)
print(gt_trn_data.shape, gt_val_data.shape, gt_tst_data.shape)


class FCNet(nn.Module):
    def __init__(self, D_in, H1, H2, D_out):
        super(FCNet, self).__init__()
        layers = [
            nn.Linear(D_in, H1),
            nn.ReLU(),
            nn.Linear(H1, H2),
            nn.ReLU(),
            nn.Linear(H2, D_out)]
        self.sequential = nn.Sequential(*layers)

    def forward(self, x):
        y_pred = self.sequential(x)
        return y_pred










fc_net_one_step = FCNet(D_in=gt_trn_data.shape[1],
                        H1=32,
                        H2=32,
                        D_out=one_step_trn_labels.shape[1])
print(fc_net_one_step)

model_parameters = filter(lambda p: p.requires_grad, fc_net_one_step.parameters())
params = sum([np.prod(p.size()) for p in model_parameters])
print(f"Number of parameters: {params}")

num_epochs = 2000
learning_rate = 0.001

criterion = torch.nn.MSELoss()    # mean-squared error for regression
optimizer = torch.optim.Adam(fc_net_one_step.parameters(), lr=learning_rate)


# Training
best_avg_rnmse_val = 10e100
best_rnmses_val_dict = {}

# Train the model
for epoch in range(num_epochs):
    one_step_predictions_trn = fc_net_one_step(gt_trn_data)

    # obtain the loss function
    trn_loss = criterion(one_step_predictions_trn, one_step_trn_labels)

    optimizer.zero_grad()
    trn_loss.backward()
    optimizer.step()

    if epoch % 100 == 0:
        with torch.no_grad():
            one_step_predictions_val = fc_net_one_step(gt_val_data)
            val_loss = criterion(one_step_predictions_val, one_step_val_labels)
        print(f"Epoch: {epoch}, trn-loss: {round(trn_loss.item(), 3)}, val-loss: {round(val_loss.item(), 3)}")

    if epoch % 5:
        # we need to iterate over the 5 steps and perform the predictions
        rNMSEs_val_dict = compute_iteration_rNMSE(fc_net_one_step, steps_ahead, val_data, val_labels)
        avg_val_rNMSE = round(np.average(list(rNMSEs_val_dict.values())), 5)

        if avg_val_rNMSE < best_avg_rnmse_val:
            # print(f"\tNew best avg val rNMSE: {avg_val_rNMSE}. Saving model...")
            torch.save({
                'epoch': epoch,
                'model_state_dict': fc_net_one_step.state_dict()
            }, "./best_fc_one_step.pth")

            best_avg_rnmse_val = avg_val_rNMSE
            best_rnmses_val_dict = rNMSEs_val_dict

print("Training complete.")

checkpoint = torch.load("./best_fc_one_step.pth")
fc_net_one_step.load_state_dict(checkpoint['model_state_dict'])
epoch = checkpoint['epoch']
fc_net_one_step.eval()
print(f"Best model was at epoch: {epoch}")

print(best_rnmses_val_dict)

rNMSEs_tst_dict = compute_iteration_rNMSE(fc_net_one_step, steps_ahead, tst_data, tst_labels)
avg_tst_rNMSE = round(np.average(list(rNMSEs_tst_dict.values())), 5)
print(rNMSEs_tst_dict)
