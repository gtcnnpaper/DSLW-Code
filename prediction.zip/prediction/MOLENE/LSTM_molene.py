import datetime

import torch
import json
from architectures.lstm import MV_LSTM

torch.cuda.current_device()

import numpy as np
import matplotlib.pyplot as plt

torch.set_default_tensor_type(torch.FloatTensor)

from prediction.evaluation import compute_iteration_rNMSE
from prediction.pred_utils import get_device, transform_data_to_all_steps_prediction, get_MOLENE_dataset
from prediction.train_utils import train_model_regression

device = get_device(use_gpu=False)

ds_folder = "../"
splits = [0.35, 0.15, 0.5]
obs_window = 4

data, steps_ahead, weighted_adjacency = get_MOLENE_dataset(
    ds_folder,
    splits=splits,
    obs_window=obs_window
)
N_spatial_nodes = weighted_adjacency.shape[0]
print(f"{N_spatial_nodes} nodes - {obs_window} observed timesteps - steps ahead: {steps_ahead}")
del weighted_adjacency

# Get data (We do not need test data/labels here)
trn_data, val_data, tst_data, trn_labels, val_labels, tst_labels = transform_data_to_all_steps_prediction(data,
                                                                                                          node_first=True,
                                                                                                          device=device)
print(trn_data.shape)

lstm_trn_data = trn_data.squeeze(1).transpose(dim0=1, dim1=2).float()
lstm_val_data = val_data.squeeze(1).transpose(dim0=1, dim1=2).float()
lstm_tst_data = tst_data.squeeze(1).transpose(dim0=1, dim1=2).float()

lstm_trn_labels_onestep = trn_labels[:, 0, :].float()
lstm_val_labels_onestep = val_labels[:, 0, :].float()


# # ------------------------------------------------------------------------------------------

input_dim = N_spatial_nodes
hidden_units = 32
N_ITERATIONS = 10
num_epochs = 1000
batch_size = 128
learning_rate = 0.001


today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")

res_dict = {
            'lr': learning_rate,
            'results': []
        }

log_dir = f"./runs_MOLENE_lstm/{today}"

for i in range(N_ITERATIONS):

    lstm_model = MV_LSTM(input_dim, obs_window, hidden_units)

    model_parameters = filter(lambda p: p.requires_grad, lstm_model.parameters())
    params = sum([np.prod(p.size()) for p in model_parameters])
    print(f"Number of parameters: {params}")

    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(lstm_model.parameters(), lr=learning_rate, weight_decay=0)

    train_model_regression(
        model=lstm_model,
        training_data=lstm_trn_data, validation_data=lstm_val_data,  # [n_samples x timesteps x nodes]
        single_step_trn_labels=lstm_trn_labels_onestep,
        single_step_val_labels=lstm_val_labels_onestep,  # [n_samples x spatial_nodes]
        num_epochs=num_epochs, batch_size=batch_size,
        loss_criterion=criterion, optimizer=optimizer, scheduler=None,
        val_metric_criterion=None,
        log_dir=log_dir,
        not_learning_limit=200
    )

    rNMSE_dict, predictions_dict = compute_iteration_rNMSE(lstm_model, steps_ahead, lstm_tst_data, tst_labels.float(),
                                                           device, verbose=False)

    res_dict['results'].append([round(l.item(), 4) for l in list(rNMSE_dict.values())])
    with open(log_dir + '/results.json', 'w', encoding='utf-8') as f:
        json.dump(res_dict, f, ensure_ascii=False, indent=4)




print(res_dict['results'])
print([round(el, 4) for el in np.average(res_dict['results'], axis=0)])
print([round(el, 4) for el in np.std(res_dict['results'], axis=0)])
