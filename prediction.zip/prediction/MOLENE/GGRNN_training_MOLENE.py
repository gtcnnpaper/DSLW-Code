from torch import nn
from architectures.space_time.grnn_ruiz.architecture import GatedGCRNNforRegression
import datetime
import numpy as np
from itertools import product
import torch
from torch.optim.lr_scheduler import ReduceLROnPlateau
from prediction.train_utils import train_model_regression
from prediction.evaluation import rNMSELoss, MSELossWithSparsityRegularizer, compute_iteration_rNMSE
from prediction.pred_utils import get_device, transform_data_to_all_steps_prediction, get_name_string, get_dataset, get_MOLENE_dataset
torch.cuda.current_device()
torch.set_default_dtype(torch.float64)
device = get_device(use_gpu=False)
import json



ds_folder = "../"
splits = [0.35, 0.15, 0.5]
obs_window = 4

data, steps_ahead, weighted_adjacency = get_MOLENE_dataset(
    ds_folder,
    splits=splits,
    obs_window=obs_window
)
N_spatial_nodes = weighted_adjacency.shape[0]
print(f"{N_spatial_nodes} nodes - {obs_window} observed timesteps - steps ahead: {steps_ahead}")


# Get data
trn_data, val_data, tst_data, trn_labels, val_labels, tst_labels = transform_data_to_all_steps_prediction(data, node_first=True, device=device)
print("Trn data size: ", trn_data.shape)

# obtain one-step labels for the training
one_step_trn_labels = trn_labels[:, 0, :]  # [batch x step-ahead x nodes]
one_step_val_labels = val_labels[:, 0, :]
print("Trn labels size: ", one_step_trn_labels.shape)



today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")





N_ITERATIONS = 10
learning_rate = 0.001
batch_size = 128
num_epochs = 1000
F1 = 3 # Number of features for the first layer
K1 = 2 # Number of filter taps for the first layer, or number of attention heads

log_dir = f"./runs_MOLENE_w={obs_window}_GGRNN/{today}_lr={learning_rate}_b={batch_size}"

res_dict = {
        'lr': learning_rate,
        'f1': F1,
        'k1': K1,
        'results': []
    }


for i in range(N_ITERATIONS):

    grnn_model = GatedGCRNNforRegression(
            inFeatures=1,
            stateFeatures=F1,
            inputFilterTaps=K1,
            stateFilterTaps=K1,
            stateNonlinearity=nn.functional.tanh,
            outputNonlinearity=nn.ReLU,
            dimLayersMLP=[N_spatial_nodes],
            GSO=weighted_adjacency,
            bias=True,
            time_gating=True,
            spatial_gating=None,
        )
    grnn_model.to(device)
    print(grnn_model)

    model_parameters = filter(lambda p: p.requires_grad, grnn_model.parameters())
    params = sum([np.prod(p.size()) for p in model_parameters])
    print(f"Number of parameters: {params}")


    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(grnn_model.parameters(), lr=learning_rate, weight_decay=0)

    train_model_regression(
            model=grnn_model,
            training_data=trn_data, validation_data=val_data,
            single_step_trn_labels=one_step_trn_labels, single_step_val_labels=one_step_val_labels,  # [n_samples x spatial_nodes]
            num_epochs=num_epochs, batch_size=batch_size,
            loss_criterion=criterion, optimizer=optimizer, scheduler=None,
            val_metric_criterion=None,
            log_dir=log_dir,
            not_learning_limit=200
        )



    rNMSE_dict, predictions_dict = compute_iteration_rNMSE(grnn_model, steps_ahead, tst_data, tst_labels,
                                                           device, verbose=False)


    res_dict['results'].append([round(l.item(), 4) for l in list(rNMSE_dict.values())])
    with open(log_dir + '/results.json', 'w', encoding='utf-8') as f:
        json.dump(res_dict, f, ensure_ascii=False, indent=4)



print(res_dict['results'])
print([round(el, 4) for el in np.average(res_dict['results'], axis=0)])
print([round(el, 4) for el in np.std(res_dict['results'], axis=0)])