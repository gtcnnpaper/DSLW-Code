import pickle

from prediction.pred_utils import convert_MOLENE_dataset_to_graph_signals, generate_dataset_from_graph_timeseries
import pandas as pd




# ------------------------------------------------------
splits = [0.35, 0.15, 0.5]
steps_ahead = [1, 2, 3, 4, 5]
observation_window = 2
assert sum(splits) == 1
# ------------------------------------------------------

in_sample = sum(splits[:-1])
dataset_path = r"./dataset/processed/"
sensor_data_name = f"sensor_data_filtered_no_means_{in_sample}.csv"
pickle_dataset_name = f"dataset_w={observation_window}_steps={steps_ahead}_splits={splits}.pickle"


sensor_data_path = dataset_path + sensor_data_name
pickle_dataset_path = dataset_path + pickle_dataset_name
stations_metadata_path = dataset_path + "weather_stations_filtered.csv"


sensor_data = pd.read_csv(sensor_data_path, index_col='date', parse_dates=True)
stations_metadata = pd.read_csv(stations_metadata_path)
stations = list(stations_metadata["Numéro"])


graph_signals = convert_MOLENE_dataset_to_graph_signals(sensor_data, stations)
print(f"{graph_signals.shape[0]} graph signals, each of dimension {graph_signals.shape[1]}")

# Let's check one last time that the data we are about to use is good.
n_timesteps = 744
for sensor_id in range(len(stations)):
    for hourly_shift in range(n_timesteps):
        assert sensor_data['t'].values[sensor_id * n_timesteps + hourly_shift] == graph_signals[hourly_shift][sensor_id]
        # we are testing that 'sorted_graph_signals' contains, for each hour, the correct 32 values of the stations, in
        # the right order.




# Let's create the dataset!
dataset, idxs = generate_dataset_from_graph_timeseries(steps_ahead, observation_window, graph_signals, splits)
print("\n-----------------------\n")
print("DATASET created.")
print(dataset.keys())
print("\t", dataset[1].keys())
print("\t", "\t", dataset[1]['trn'].keys())
print(dataset[1]['trn']['data'].shape)
print(dataset[1]['trn']['labels'].shape)
print(dataset[1]['val']['data'].shape)
print(dataset[1]['val']['labels'].shape)
print(dataset[1]['tst']['data'].shape)
print(dataset[1]['tst']['labels'].shape)
print("\n-----------------------\n")




# Let's save it
trn_indices, val_indices, tst_indices = idxs
metadata = {
    'total_timesteps': len(trn_indices) + len(val_indices) + len(tst_indices),
    'trn_timesteps': len(trn_indices),
    'val_timesteps': len(val_indices),
    'tst_timesteps': len(tst_indices)
}
dataset['metadata'] = metadata

with open(pickle_dataset_path, 'wb') as handle:
    pickle.dump(dataset, handle, protocol=pickle.HIGHEST_PROTOCOL)

with open(pickle_dataset_path, 'rb') as handle:
    dt = pickle.load(handle)

print("DONE")
