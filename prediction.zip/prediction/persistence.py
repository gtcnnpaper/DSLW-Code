import matplotlib.pyplot as plt


def persistence_prediction(data):
    """
    :param data: [n_samples x observation_window x n_nodes]
    :return: [n_samples x n_nodes]: the last observed signal
    """
    assert len(data.shape) == 3
    return data[:, -1, :]


def visualize_persistence_baseline(dataset_for_step, station_id, idxs_to_show=None):
    y_true = dataset_for_step['labels']
    y_pred = dataset_for_step['data'][:, -1, :]  # last observation

    if idxs_to_show:
        y_true = y_true[idxs_to_show]
        y_pred = y_pred[idxs_to_show]

    assert y_true.shape == y_pred.shape
    assert station_id is not None

    indices = list(range(y_pred.shape[0]))

    station_y_test = y_true[:, station_id]
    station_y_pred = y_pred[:, station_id]
    plt.figure(figsize=(18, 4))
    plt.plot(indices, station_y_test, 'g', label='truth')  # plotting t, a separately
    plt.plot(indices, station_y_pred, 'r', label='pred')  # plotting t, b separately
    plt.legend()
    plt.show()
