import datetime
import json

import torch

from architectures.lstm import MV_LSTM
from prediction.NOAA.difference_utils import perform_step_ahead_deltas, compute_iteration_rNMSE_with_deltas

torch.cuda.current_device()

import numpy as np

torch.set_default_tensor_type(torch.FloatTensor)

from prediction.pred_utils import get_device, transform_data_to_all_steps_prediction, get_NOAA_dataset
from prediction.train_utils import train_model_regression

device = get_device(use_gpu=False)

ds_folder = "../.."
splits = [0.35, 0.15, 0.5]
obs_window = 4

data_diff, steps_ahead, weighted_adjacency = get_NOAA_dataset(
    ds_folder,
    splits=splits,
    obs_window=obs_window,
    differenced=True,
)

N_spatial_nodes = weighted_adjacency.shape[0]
print(f"{N_spatial_nodes} nodes - {obs_window} observed timesteps - steps ahead: {steps_ahead}")
del weighted_adjacency

# Get data
trn_data_deltas, val_data_deltas, tst_data_deltas, trn_labels_deltas, val_labels_deltas, tst_labels_deltas = transform_data_to_all_steps_prediction(
    data_diff,
    node_first=True,
    device=device)
print(trn_data_deltas.shape)

lstm_trn_data = trn_data_deltas.squeeze(1).transpose(dim0=1, dim1=2).float()
lstm_val_data = val_data_deltas.squeeze(1).transpose(dim0=1, dim1=2).float()
lstm_tst_data = tst_data_deltas.squeeze(1).transpose(dim0=1, dim1=2).float()

lstm_trn_labels_onestep = trn_labels_deltas[:, 0, :].float()
lstm_val_labels_onestep = val_labels_deltas[:, 0, :].float()

input_dim = N_spatial_nodes
hidden_units = 64
seq_len = obs_window
num_epochs = 50
batch_size = 32
today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
log_dir = f"./runs_NOAA_LSTM_insample/{today}"

insample_percentages = [2.5, 5, 15, 25]
N_ITERATIONS_PER_PERC = 10

results_dict = {} # keys will be the percentages, and values will be the lists of rNMSEs
for insample_perc in insample_percentages:
    print(insample_perc)
    perc_to_subset = insample_perc / 35
    reduced_trn_data = lstm_trn_data[-int(lstm_trn_data.shape[0] * perc_to_subset):]
    reduced_trn_labels_onestep = lstm_trn_labels_onestep[-int(lstm_trn_data.shape[0] * perc_to_subset):]
    print(reduced_trn_data.shape, reduced_trn_labels_onestep.shape)

    # for each insample_perc, we track the rNMSEs across the iterations
    perc_rNMSEs = []
    for iteration in range(N_ITERATIONS_PER_PERC):


        # # ------------------------------------------------------------------------------------------
        lstm_model = MV_LSTM(input_dim, seq_len, hidden_units)

        model_parameters = filter(lambda p: p.requires_grad, lstm_model.parameters())
        params = sum([np.prod(p.size()) for p in model_parameters])
        print(f"Number of parameters: {params}")

        criterion = torch.nn.MSELoss()
        optimizer = torch.optim.Adam(lstm_model.parameters(), lr=0.005, weight_decay=0.005)

        best_model, best_epoch = train_model_regression(
            model=lstm_model,
            training_data=reduced_trn_data, validation_data=lstm_val_data,  # [n_samples x timesteps x nodes]
            single_step_trn_labels=reduced_trn_labels_onestep,
            single_step_val_labels=lstm_val_labels_onestep,  # [n_samples x spatial_nodes]
            num_epochs=num_epochs, batch_size=batch_size,
            loss_criterion=criterion, optimizer=optimizer, scheduler=None,
            val_metric_criterion=None,
            log_dir=log_dir,
            not_learning_limit=50
        )

        orig_dataset, _, _ = get_NOAA_dataset(
            ds_folder,
            splits=splits,
            obs_window=obs_window,
            differenced=False,
        )
        _, _, _, orig_trn_labels, orig_val_labels, orig_tst_labels = transform_data_to_all_steps_prediction(orig_dataset,
                                                                                                            node_first=True,
                                                                                                            device=device)

        deltas_predictions_dict, cum_delta_pred_dict_tst = perform_step_ahead_deltas(lstm_tst_data, best_model, steps_ahead,
                                                                                     verbose=False)
        tst_rNMSEs, _ = compute_iteration_rNMSE_with_deltas(
            cumulative_deltas_dict=cum_delta_pred_dict_tst,
            original_one_step_labels=orig_tst_labels[:, 0, :].float(),
            verbose=True
        )


        perc_rNMSEs.append(tst_rNMSEs)

    results_dict[insample_perc] = perc_rNMSEs


means = []
stds = []
percs = []
for perc, values in results_dict.items():
    mean = [round(el, 4) for el in np.average(values, axis=0)]
    std = [round(el, 4) for el in np.std(values, axis=0)]
    means.append(mean)
    stds.append(std)
    percs.append(perc)

final_values = {
    'percentages': percs,
    'means': means,
    'stds': stds,
    'n_iterations_per_perc': N_ITERATIONS_PER_PERC
}

with open(log_dir + f'/final_values.json', 'w', encoding='utf-8') as f:
    json.dump(final_values, f, ensure_ascii=False, indent=4)
