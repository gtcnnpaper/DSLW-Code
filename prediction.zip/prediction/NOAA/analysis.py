import os
import numpy as np
from prediction.pred_utils import run_graph_signals_timeseries_analysis
from utils.misc_utils import check_create_folder


dataset_path = r"C:\\Users\\gabri\\Desktop\\new_thesis_project\\prediction\\NOAA\\dataset\\"
timeseries_data_path = dataset_path + "NOA_109_data.npy"
adjacency_matrix_path = dataset_path + "NOA_109_weighted_adj.npy"

adj = np.load(file=adjacency_matrix_path)
timeseries = np.load(file=timeseries_data_path)

results_path = os.path.join(dataset_path, "..", "analysis_results")
check_create_folder(results_path)
splits = [0.35, 0.15, 0.5]


run_graph_signals_timeseries_analysis(timeseries, results_path, splits,
                                      do_timeseries=False,
                                      do_distributions=False
                                      )
