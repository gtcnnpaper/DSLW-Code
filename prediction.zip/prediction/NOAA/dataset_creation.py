import os
import pickle

import numpy as np

from prediction.pred_utils import generate_dataset_from_graph_timeseries

splits = [0.35, 0.15, 0.5]
steps_ahead = [1, 2, 3, 4, 5]
observation_window = 4

DIFFERENCE = False

dataset_path = r"C:\\Users\\gabri\\Desktop\\new_thesis_project\\prediction\\NOAA\\dataset\\"
timeseries_data_path = dataset_path + "original/NOA_109_data.npy"
pickle_dataset_path = dataset_path + f"processed/NOA_w={observation_window}_steps={steps_ahead}_splits={splits}.pickle"
in_sample_means_dict_path = dataset_path + f"processed/in_sample_means_{sum(splits[:-1])}.pickle"

if DIFFERENCE:
    timeseries_data_path = dataset_path + "processed/NOA_109_data_differenced.npy"
    pickle_dataset_path = dataset_path + f"processed/NOA_w={observation_window}_steps={steps_ahead}_splits={splits}_differenced.pickle"
    in_sample_means_dict_path = ""




timeseries_data = np.load(file=timeseries_data_path)

if not DIFFERENCE:
    # Remove in-sample means
    in_sample_means = {}
    n_stations = timeseries_data.shape[0]
    n_timesteps = timeseries_data.shape[1]
    val_test_line_idx = int(n_timesteps * (splits[0]+splits[1]))

    timeseries_data_no_means = timeseries_data.copy()
    for station_idx in range(n_stations):
        station_timeseries = timeseries_data[station_idx, :]
        in_sample_mean = np.mean(station_timeseries[:val_test_line_idx])
        station_timeseries_no_mean = station_timeseries - in_sample_mean
        timeseries_data_no_means[station_idx, :] = station_timeseries_no_mean
        in_sample_means[station_idx] = in_sample_mean

    # timeseries is [n_stations x n_timesteps] --> the function wants [n_timesteps x n_stations]
    dataset, idxs = generate_dataset_from_graph_timeseries(steps_ahead, observation_window,
                                                           timeseries_data_no_means.transpose(), splits)
else:
    dataset, idxs = generate_dataset_from_graph_timeseries(steps_ahead, observation_window,
                                                           timeseries_data.transpose(), splits)


print("\n-----------------------\n")
print("DATASET created.")
print(dataset.keys())
print("\t", dataset[1].keys())
print("\t", "\t", dataset[1]['trn'].keys())
print(dataset[1]['trn']['data'].shape)
print(dataset[1]['trn']['labels'].shape)
print(dataset[1]['val']['data'].shape)
print(dataset[1]['val']['labels'].shape)
print(dataset[1]['tst']['data'].shape)
print(dataset[1]['tst']['labels'].shape)
print("\n-----------------------\n")




# Let's save it
trn_indices, val_indices, tst_indices = idxs
metadata = {
    'total_timesteps': len(trn_indices) + len(val_indices) + len(tst_indices),
    'trn_timesteps': len(trn_indices),
    'val_timesteps': len(val_indices),
    'tst_timesteps': len(tst_indices)
}
dataset['metadata'] = metadata

with open(pickle_dataset_path, 'wb') as handle:
    pickle.dump(dataset, handle, protocol=pickle.HIGHEST_PROTOCOL)

with open(pickle_dataset_path, 'rb') as handle:
    dt = pickle.load(handle)

if not DIFFERENCE:
    with open(in_sample_means_dict_path, 'wb') as handle:
        pickle.dump(in_sample_means, handle, protocol=pickle.HIGHEST_PROTOCOL)

print("DONE")
