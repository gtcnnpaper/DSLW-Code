import datetime
import json

import torch

from architectures.lstm import MV_LSTM
from prediction.NOAA.difference_utils import perform_step_ahead_deltas, compute_iteration_rNMSE_with_deltas, \
    visualize_predictions, visualize_deltas

torch.cuda.current_device()

import numpy as np
import matplotlib.pyplot as plt

torch.set_default_tensor_type(torch.FloatTensor)

from prediction.evaluation import compute_iteration_rNMSE
from prediction.pred_utils import get_device, transform_data_to_all_steps_prediction, get_NOAA_dataset
from prediction.train_utils import train_model_regression

device = get_device(use_gpu=False)

ds_folder = "../"
splits = [0.35, 0.15, 0.5]
obs_window = 4
num_epochs = 50
batch_size = 32
learning_rate = 0.005
wd = 0.005
N_ITERATIONS = 5



data_diff, steps_ahead, weighted_adjacency = get_NOAA_dataset(
    ds_folder,
    splits=splits,
    obs_window=obs_window,
    differenced=True,
)

N_spatial_nodes = weighted_adjacency.shape[0]
print(f"{N_spatial_nodes} nodes - {obs_window} observed timesteps - steps ahead: {steps_ahead}")
del weighted_adjacency


input_dim = N_spatial_nodes
hidden_units = 64
seq_len = obs_window


# Get data
trn_data_deltas, val_data_deltas, tst_data_deltas, trn_labels_deltas, val_labels_deltas, tst_labels_deltas = transform_data_to_all_steps_prediction(data_diff,
                                                                                                          node_first=True,
                                                                                                          device=device)
print(trn_data_deltas.shape)

lstm_trn_data = trn_data_deltas.squeeze(1).transpose(dim0=1, dim1=2).float()
lstm_val_data = val_data_deltas.squeeze(1).transpose(dim0=1, dim1=2).float()
lstm_tst_data = tst_data_deltas.squeeze(1).transpose(dim0=1, dim1=2).float()

lstm_trn_labels_onestep = trn_labels_deltas[:, 0, :].float()
lstm_val_labels_onestep = val_labels_deltas[:, 0, :].float()


# # ------------------------------------------------------------------------------------------

today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
log_dir = f"./runs_NOAA_lstm/{today}_lr={learning_rate}_b={batch_size}"

res_dict = {
        'lr': learning_rate,
        'results': []
    }


for i in range(N_ITERATIONS):

    lstm_model = MV_LSTM(input_dim, seq_len, hidden_units)

    model_parameters = filter(lambda p: p.requires_grad, lstm_model.parameters())
    params = sum([np.prod(p.size()) for p in model_parameters])
    print(f"Number of parameters: {params}")





    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(lstm_model.parameters(), lr=learning_rate, weight_decay=wd)


    train_model_regression(
        model=lstm_model,
        training_data=lstm_trn_data, validation_data=lstm_val_data,  # [n_samples x timesteps x nodes]
        single_step_trn_labels=lstm_trn_labels_onestep,
        single_step_val_labels=lstm_val_labels_onestep,  # [n_samples x spatial_nodes]
        num_epochs=num_epochs, batch_size=batch_size,
        loss_criterion=criterion, optimizer=optimizer, scheduler=None,
        val_metric_criterion=None,
        log_dir=log_dir,
        not_learning_limit=20
    )


    orig_dataset, _, _ = get_NOAA_dataset(
        ds_folder,
        splits=splits,
        obs_window=obs_window,
        differenced=False,
    )
    _, _, _, _, _, orig_tst_labels = transform_data_to_all_steps_prediction(orig_dataset, node_first=True, device=device)


    deltas_predictions_dict, cum_delta_pred_dict_tst = perform_step_ahead_deltas(lstm_tst_data, lstm_model, steps_ahead, verbose=True)
    tst_rNMSEs, _ = compute_iteration_rNMSE_with_deltas(
        cumulative_deltas_dict=cum_delta_pred_dict_tst,
        original_one_step_labels=orig_tst_labels[:, 0, :].float(),
        verbose=True
    )
    print("rNMSEs: ", tst_rNMSEs)
    avg_tst_rNMSEs = round(np.average(tst_rNMSEs), 5)
    tst_values = (avg_tst_rNMSEs, tst_rNMSEs)
    print(tst_values[1])

    # visualize_predictions(
    #     cum_delta_pred_dict_tst,
    #     orig_tst_labels[:, 0, :],
    #     start=1000,
    #     width=600,
    #     node=60,
    #     type_of_data='Test'
    # )
    #
    # visualize_deltas(
    #     deltas_predictions_dict,
    #     tst_labels_deltas,
    #     start=0,
    #     width=88,
    #     node=60,
    #     type_of_data='Test'
    # )

    res_dict['results'].append(tst_rNMSEs)

    means = [round(el, 4) for el in np.average(res_dict['results'], axis=0)]
    stds = [round(el, 4) for el in np.std(res_dict['results'], axis=0)]
    res_dict['final_res'] = {
        'avg': means,
        'std': stds
    }

    with open(log_dir + '/results.json', 'w', encoding='utf-8') as f:
        json.dump(res_dict, f, ensure_ascii=False, indent=4)

    print(res_dict['results'])

print(res_dict['results'])
means = [round(el, 4) for el in np.average(res_dict['results'], axis=0)]
stds = [round(el, 4) for el in np.std(res_dict['results'], axis=0)]
print(means)
print(stds)

res_dict['final_res'] = {
    'avg': means,
    'std': stds
}
with open(log_dir + '/results.json', 'w', encoding='utf-8') as f:
    json.dump(res_dict, f, ensure_ascii=False, indent=4)