import torch

from architectures.lstm import MV_LSTM

torch.cuda.current_device()

import numpy as np
import matplotlib.pyplot as plt

torch.set_default_tensor_type(torch.FloatTensor)

from prediction.evaluation import compute_iteration_rNMSE
from prediction.pred_utils import get_device, transform_data_to_all_steps_prediction, get_NOAA_dataset
from prediction.train_utils import train_model_regression

device = get_device(use_gpu=False)

ds_folder = "../"
splits = [0.35, 0.15, 0.5]
obs_window = 4

data, steps_ahead, weighted_adjacency = get_NOAA_dataset(
    ds_folder,
    splits=splits,
    obs_window=obs_window,
    differenced=False
)

N_spatial_nodes = weighted_adjacency.shape[0]
print(f"{N_spatial_nodes} nodes - {obs_window} observed timesteps - steps ahead: {steps_ahead}")
del weighted_adjacency

# Get data (We do not need test data/labels here)
trn_data, val_data, tst_data, trn_labels, val_labels, tst_labels = transform_data_to_all_steps_prediction(data,
                                                                                                          node_first=True,
                                                                                                          device=device)
print(trn_data.shape)

lstm_trn_data = trn_data.squeeze(1).transpose(dim0=1, dim1=2).float()
lstm_val_data = val_data.squeeze(1).transpose(dim0=1, dim1=2).float()
lstm_tst_data = tst_data.squeeze(1).transpose(dim0=1, dim1=2).float()

lstm_trn_labels_onestep = trn_labels[:, 0, :].float()
lstm_val_labels_onestep = val_labels[:, 0, :].float()


# # ------------------------------------------------------------------------------------------

input_dim = N_spatial_nodes
hidden_units = 256
seq_len = obs_window

lstm_model = MV_LSTM(input_dim, seq_len, hidden_units)

model_parameters = filter(lambda p: p.requires_grad, lstm_model.parameters())
params = sum([np.prod(p.size()) for p in model_parameters])
print(f"Number of parameters: {params}")



num_epochs = 1000
batch_size = 128

criterion = torch.nn.MSELoss()
optimizer = torch.optim.Adam(lstm_model.parameters(), lr=0.005, weight_decay=0.005)

log_dir = "./lstm/"


train_model_regression(
    model=lstm_model,
    training_data=lstm_trn_data, validation_data=lstm_val_data,  # [n_samples x timesteps x nodes]
    single_step_trn_labels=lstm_trn_labels_onestep,
    single_step_val_labels=lstm_val_labels_onestep,  # [n_samples x spatial_nodes]
    num_epochs=num_epochs, batch_size=batch_size,
    loss_criterion=criterion, optimizer=optimizer, scheduler=None,
    val_metric_criterion=None,
    log_dir=log_dir,
    not_learning_limit=20
)





rNMSE_dict, predictions_dict = compute_iteration_rNMSE(lstm_model, steps_ahead, lstm_tst_data, tst_labels.float(),
                                                       device, verbose=False)



print([round(l.item(), 4) for l in list(rNMSE_dict.values())])


node_to_visualize = 7  # 20 and 7  is good. 13 is terrible.
step_ahead = 1

pred = predictions_dict[step_ahead][:, node_to_visualize].cpu()
truth = tst_labels[:, step_ahead - 1, node_to_visualize].cpu()
assert pred.shape == truth.shape
indices = list(range(truth.shape[0]))

truth_style = '-'
pred_style = ':'
# plot of all_data
plt.figure(figsize=(10, 4))
plt.plot(indices, truth[indices], 'b', linestyle=truth_style, label='truth')  # plotting t, a separately
plt.plot(indices, pred[indices], 'g', linestyle=pred_style, label='LSTM', linewidth=3)  # plotting t, b separately

# title = f"Station {station_idx}: {station_names[station_idx]} ({station_num})"
plt.xlabel("Time (Hours)", fontsize=18)
plt.ylabel("Temperature (Kelvin degrees)", fontsize=18)
plt.xticks(fontsize=15)
plt.yticks(fontsize=15)

plt.legend(fontsize=15)


# plt.savefig(figure_dir + name.split('\\')[-1] + f"_typeOfSort={type_of_sort}_rank={model_number}_station{node_to_visualize}_step{step_ahead}.png")

plt.show()
