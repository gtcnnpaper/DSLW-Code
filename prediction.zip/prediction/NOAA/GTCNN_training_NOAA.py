import datetime
import numpy as np
from itertools import product
import torch
from torch.optim.lr_scheduler import ReduceLROnPlateau

from architectures.space_time.parametric_pooling_net_ordering import ParametricNetWithPoolingOrdered
from prediction.train_utils import train_model_regression
from prediction.evaluation import MSELossWithSparsityRegularizer
from prediction.pred_utils import get_device, transform_data_to_all_steps_prediction, get_name_string, get_NOAA_dataset
from utils.misc_utils import check_create_folder

torch.cuda.current_device()
torch.set_default_dtype(torch.float64)



# torch.manual_seed(123)
# np.random.seed(123)
# random.seed(123)

device = get_device(use_gpu=True)

ds_folder = "../"
splits = [0.35, 0.15, 0.5]
obs_window = 4
DIFFERENCE = True

data, steps_ahead, weighted_adjacency = get_NOAA_dataset(
    ds_folder,
    splits=splits,
    obs_window=obs_window,
    differenced=DIFFERENCE,
)
N_spatial_nodes = weighted_adjacency.shape[0]
print(f"{N_spatial_nodes} nodes - {obs_window} observed timesteps - steps ahead: {steps_ahead}")










# Get data (We do not need test data/labels here)
trn_data, val_data, _, trn_labels, val_labels, _ = transform_data_to_all_steps_prediction(data, node_first=True, device=device)
print(trn_data.shape, val_data.shape)
# obtain one-step labels for the training
one_step_trn_labels = trn_labels[:, 0, :]  # [batch x step-ahead x nodes]
one_step_val_labels = val_labels[:, 0, :]
print(one_step_trn_labels.shape, one_step_val_labels.shape)

num_epochs = 200
learning_rates = [0.01]  # 0.0005
weight_decays = [0, 0.0025]  # , 0.00001, 0]
batch_sizes = [256]  # 32
patience = 25
factor = 0.9

not_learning_limit = 100

perc_nodes_1 = [0.8, 1]
perc_nodes_2 = [0.5, 0.7]

n_features_1 = [4, 8]
n_features_2 = [8, 12]

taps_1 = [2]
taps_2 = [2]

lambdas = [0, 0.00025]  # 0.00025, 0.0005, 0.001, 0.005, 0.01, 0.05]

time_pooling_ratios = [
    [1, 4],
    [2, 2]
]

p_reaches = [
    [1, 1],
    # [2, 2]
]

cyclics = [True]
time_directness = [True]


for model_number, \
    (learning_rate, batch_size,
     nodes_1, nodes_2,
     n_feat_1, n_feat_2,
     tap_1, tap_2,
     t_pool,
     w_decay,
     cyclic,
     lambda_reg,
     time_directed,
     p_reach) in \
        enumerate(product(learning_rates, batch_sizes,
                          perc_nodes_1, perc_nodes_2,
                          n_features_1, n_features_2,
                          taps_1, taps_2,
                          time_pooling_ratios,
                          weight_decays,
                          cyclics,
                          lambdas,
                          time_directness,
                          p_reaches)):


    # if model_number <= 111:
    #     continue

    print(f"\n\n\nStarting new training (model {model_number}) --> "
          f"lr: {learning_rate} | "
          f"batch_size: {batch_size} | "
          f"perc_nodes_1: {nodes_1} | "
          f"perc_nodes_1: {nodes_2} | "
          f"n_feat_1: {n_feat_1} | "
          f"n_feat_2: {n_feat_2} | "
          f"time_pooling_ratios: {t_pool} | "
          f"weight_decay: {w_decay} | "
          f"cyclic: {cyclic} | "
          f"lambda: {lambda_reg} | "
          f"time directed: {time_directed}")

    # GTCNN
    feat_per_layer = [1, n_feat_1, n_feat_2]
    taps_per_layer = [tap_1, tap_2]
    active_nodes_per_timestep_per_layer = [
        N_spatial_nodes,
        int(N_spatial_nodes * nodes_1),
        int(N_spatial_nodes * nodes_2)]
    time_pooling_ratio_per_layer = t_pool
    pool_reach_per_layer = p_reach

    one_step_gtcnn = ParametricNetWithPoolingOrdered(
        window=obs_window,
        cyclic_time_graph=cyclic,
        time_directed=time_directed,
        S_spatial=weighted_adjacency,
        n_feat_per_layer=feat_per_layer,
        n_taps_per_layer=taps_per_layer,
        n_active_nodes_per_timestep_per_layer=active_nodes_per_timestep_per_layer,
        time_pooling_ratio_per_layer=time_pooling_ratio_per_layer,
        pool_reach_per_layer=pool_reach_per_layer,
        output_dim=N_spatial_nodes,
        device=device)
    one_step_gtcnn.to(device)
    print(one_step_gtcnn)

    model_parameters = filter(lambda p: p.requires_grad, one_step_gtcnn.parameters())
    params = sum([np.prod(p.size()) for p in model_parameters])
    print(f"Number of parameters: {params}")

    today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    name_string = get_name_string(
        obs_window,
        feat_per_layer, taps_per_layer, time_pooling_ratio_per_layer,
        pool_reach_per_layer, active_nodes_per_timestep_per_layer,
        w_decay, cyclic, lambda_reg, time_directed
    )
    log_dir = f"./runs_NOAA_w={obs_window}_diff={DIFFERENCE}/{today}_lr={learning_rate}_b={batch_size}_{name_string}"
    check_create_folder(log_dir)

    ### TRAINING ###
    # loss_criterion = rNMSELossWithSparsityRegularizer(one_step_gtcnn, lambda_reg)
    loss_criterion = MSELossWithSparsityRegularizer(one_step_gtcnn, lambda_reg)

    val_metric = None # rNMSELoss()

    optimizer = torch.optim.Adam(one_step_gtcnn.parameters(), lr=learning_rate, weight_decay=w_decay)
    scheduler = ReduceLROnPlateau(optimizer, 'min', patience=patience, factor=factor)

    train_model_regression(
        model=one_step_gtcnn,
        training_data=trn_data, validation_data=val_data,  # [n_samples x 1 x nodes x timesteps]
        single_step_trn_labels=one_step_trn_labels, single_step_val_labels=one_step_val_labels,  # [n_samples x spatial_nodes]
        num_epochs=num_epochs, batch_size=batch_size,
        loss_criterion=loss_criterion, optimizer=optimizer, scheduler=scheduler,
        val_metric_criterion=val_metric,
        log_dir=log_dir,
        not_learning_limit=not_learning_limit
    )
