import ast
import torch
torch.cuda.current_device()

import pickle
torch.set_default_dtype(torch.float64)
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from prediction.evaluation import perform_chunk_predictions, rNMSE
from prediction.pred_utils import get_device, transform_data_to_all_steps_prediction, get_NOAA_dataset

from architectures.space_time.parametric_pooling_net_ordering import ParametricNetWithPoolingOrdered


device = get_device(use_gpu=True)


runs_dir = "C:\\Users\\gabri\\Desktop\\new_thesis_project\\prediction\\NOAA\\runs_NOAA_w=4_diff=True\\"
model_name = "20200203172708_lr=0.01_b=128_w=4_L=2_F=[8, 8]_T=[2, 2]_P=[1, 4]_R=[1, 1]_N=[109, 54]_wd=0_cyclic=True_lambda=0_tdirect=True"
model_path = runs_dir + model_name

cyclic = 'cyclic=True' in model_name
time_directed = 'tdirect=False' not in model_name
BEST = True


















####################### DATA ################################
ds_folder = "../"
splits = [0.35, 0.15, 0.5]
obs_window = 4

dataset_differences, steps_ahead, weighted_adjacency = get_NOAA_dataset(
    ds_folder,
    splits=splits,
    obs_window=obs_window,
    differenced=True,
)
_, _, tst_data_deltas, _, _, tst_labels_deltas = transform_data_to_all_steps_prediction(dataset_differences, node_first=True, device=device)
N_spatial_nodes = weighted_adjacency.shape[0]
print(f"{N_spatial_nodes} nodes - {obs_window} observed timesteps - steps ahead: {steps_ahead}")
print("Deltas test data shape: ", tst_data_deltas.shape)
print("Deltas test labels shape: ", tst_labels_deltas.shape)

orig_dataset, _, _ = get_NOAA_dataset(
    ds_folder,
    splits=splits,
    obs_window=obs_window,
    differenced=False,
)
_, _, orig_tst_data, _, _, orig_tst_labels = transform_data_to_all_steps_prediction(orig_dataset, node_first=True, device=device)
print("Original test data shape: ", orig_tst_data.shape)
print("Original test labels shape: ", orig_tst_labels.shape)

assert orig_tst_data.shape[0] == tst_data_deltas.shape[0] + 1
assert orig_tst_labels.shape[0] == tst_labels_deltas.shape[0] + 1









import sys
sys.exit(-123)




##################### MODEL ################################
start = 5

features = ast.literal_eval(model_name.split("_")[start].split("=")[1])
taps = ast.literal_eval(model_name.split("_")[start+1].split("=")[1])
pool_ratios = ast.literal_eval(model_name.split("_")[start+2].split("=")[1])
reach = ast.literal_eval(model_name.split("_")[start+3].split("=")[1])
nodes = ast.literal_eval(model_name.split("_")[start+4].split("=")[1])

feat_per_layer = [1] + features
taps_per_layer = taps
pool_reach_per_layer = reach
active_nodes_per_timestep_per_layer = [N_spatial_nodes] + nodes
time_pooling_ratio_per_layer = pool_ratios



one_step_gtcnn = ParametricNetWithPoolingOrdered(
    window=obs_window,
    cyclic_time_graph=cyclic,
    time_directed=time_directed,
    S_spatial=weighted_adjacency,
    n_feat_per_layer=feat_per_layer,
    n_taps_per_layer=taps_per_layer,
    n_active_nodes_per_timestep_per_layer=active_nodes_per_timestep_per_layer,
    time_pooling_ratio_per_layer=time_pooling_ratio_per_layer,
    pool_reach_per_layer=pool_reach_per_layer,
    output_dim=N_spatial_nodes,
    device=device)

one_step_gtcnn.to(device)
model_parameters = filter(lambda p: p.requires_grad, one_step_gtcnn.parameters())
params = sum([np.prod(p.size()) for p in model_parameters])
print(f"Number of parameters: {params}")

naming = "best" if BEST else "last"
checkpoint = torch.load(f"{model_path}/{naming}_one_step_gtcnn.pth")

one_step_gtcnn.load_state_dict(checkpoint['model_state_dict'])
epoch = checkpoint['epoch']

one_step_gtcnn.eval()
print(f"{naming} model was at epoch: {epoch}")

















######################### DIFFERENCES ###################################
def invert_difference_graph_signals(orig_data, deltas, interval):
    signals = []
    for i in range(interval, orig_data.shape[0]):
        restored_value = orig_data[i - interval, :] + deltas[i - interval, :]
        signals.append(restored_value)
    stacked_signals = torch.stack(signals)
    return stacked_signals




# new version of the iteration rNMSEs for the delta predictions
model = one_step_gtcnn
data = tst_data_deltas  # [4371 x 1 x 109 x 4]
labels = orig_tst_labels  # [4372 x 5 x 109]

rNMSE_dict = {}
data_for_prediction = data.clone()
predictions_dict = {}
for step in steps_ahead:  # [1, 2, 3, 4, 5]
    print(f"\nComputing delta predictions for {step}-step ahead.")
    step_idx = step - 1
    assert 0 <= step_idx < 5

    with torch.no_grad():
        delta_predictions = perform_chunk_predictions(model, data_for_prediction, 100)  # [4371 x 109]
        predictions_dict[step] = delta_predictions.clone()

    data_for_prediction = torch.cat((data_for_prediction, delta_predictions.unsqueeze(1).unsqueeze(-1)), dim=-1)[:, :, :, 1:]


cumulative_delta_predictions_dict = {}
print("\n\n\n")
for step in predictions_dict.keys():
    print(f"Building cumulative step predictions for step {step}")
    cumulative_predictions_for_step = torch.zeros(predictions_dict[step].shape)
    for step_to_sum in range(1, step+1):
        # print(f"Summing step {step_to_sum}")
        cumulative_predictions_for_step += predictions_dict[step_to_sum].cpu()
    cumulative_delta_predictions_dict[step] = cumulative_predictions_for_step

    persistence_delta_predictions = torch.zeros(predictions_dict[step].shape)

    original_one_step_values = labels[:, 0, :]
    rnmse = rNMSE(original_one_step_values[step:].cpu(), invert_difference_graph_signals(original_one_step_values.cpu(), cumulative_predictions_for_step.cpu(), step))
    print(rnmse)

    pers_rnmse = rNMSE(original_one_step_values[step:].cpu(), invert_difference_graph_signals(original_one_step_values.cpu(), persistence_delta_predictions.cpu(), step))
    print(pers_rnmse)

print()
print()




