from pygsp import graphs, plotting
import matplotlib.pyplot as plt
import numpy as np

plotting.BACKEND = 'matplotlib'
plt.rcParams['figure.figsize'] = (10, 5)
import sys
np.set_printoptions(threshold=sys.maxsize)

dataset_path = r"C:\\Users\\gabri\\Desktop\\new_thesis_project\\prediction\\NOAA\\dataset\\"
adjacency_matrix_path = dataset_path + "original/NOA_109_original_adj.npy"
new_adjacency_matrix_path = dataset_path + "processed/weighted_adj.npy"


adj = np.load(file=adjacency_matrix_path)
adj = adj / np.max(adj)


NN = 7
G = graphs.NNGraph(adj, k=NN)
G.set_coordinates()
_, axes = plt.subplots(1, 2)
_ = axes[0].spy(G.W, markersize=5)
G.plot(ax=axes[1])
plt.show()

W = np.asarray(G.W.todense())

np.save(file=new_adjacency_matrix_path, arr=W)

print()