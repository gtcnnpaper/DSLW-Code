import datetime
import json

import numpy as np
from itertools import product
import torch
from torch.optim.lr_scheduler import ReduceLROnPlateau

from architectures.space_time.parametric_pooling_net_ordering import ParametricNetWithPoolingOrdered
from prediction.NOAA.difference_utils import perform_step_ahead_deltas, compute_iteration_rNMSE_with_deltas, \
    visualize_predictions, visualize_deltas
from prediction.train_utils import train_model_regression
from prediction.evaluation import MSELossWithSparsityRegularizer, rNMSELoss
from prediction.pred_utils import get_device, transform_data_to_all_steps_prediction, get_name_string, get_NOAA_dataset
from utils.misc_utils import check_create_folder

torch.cuda.current_device()

device = get_device(use_gpu=True)

ds_folder = "../.."
splits = [0.35, 0.15, 0.5]
obs_window = 4
DIFFERENCE = True

data, steps_ahead, weighted_adjacency = get_NOAA_dataset(
    ds_folder,
    splits=splits,
    obs_window=obs_window,
    differenced=DIFFERENCE,
)
N_spatial_nodes = weighted_adjacency.shape[0]
print(f"{N_spatial_nodes} nodes - {obs_window} observed timesteps - steps ahead: {steps_ahead}")





name = 'PARAMETRIC'




# Get data
trn_data, val_data, tst_data_deltas, trn_labels, val_labels, tst_labels_deltas = transform_data_to_all_steps_prediction(data, node_first=True, device=device)
trn_data = trn_data.float()
val_data = val_data.float()
tst_data_deltas = tst_data_deltas.float()
trn_labels = trn_labels.float()
val_labels = val_labels.float()
tst_labels_deltas = tst_labels_deltas.float()
print(trn_data.shape, val_data.shape)

# obtain one-step labels for the training
one_step_trn_labels = trn_labels[:, 0, :]  # [batch x step-ahead x nodes]
one_step_val_labels = val_labels[:, 0, :]
print(one_step_trn_labels.shape, one_step_val_labels.shape)


N_ITERATIONS = 5
num_epochs = 400
learning_rate = 0.01# 0.0005
weight_decay = 0.0025  # , 0.00001, 0]
batch_size = 256  # 32
patience = 100
factor = 0.9

not_learning_limit = 100

perc_nodes_1 = 1
perc_nodes_2 = 0.5

n_features_1 = 4
n_features_2 = 8

taps_1 = 2
taps_2 = 2

lambda_value = 0  # 0.00025, 0.0005, 0.001, 0.005, 0.01, 0.05]

time_pooling_ratios = [2, 2]

p_reaches = [1, 1]

cyclic = True
time_directed = True



# GTCNN
feat_per_layer = [1, n_features_1, n_features_2]
taps_per_layer = [taps_1, taps_2]
active_nodes_per_timestep_per_layer = [
    N_spatial_nodes,
    int(N_spatial_nodes * perc_nodes_1),
    int(N_spatial_nodes * perc_nodes_2)]
time_pooling_ratio_per_layer = time_pooling_ratios
pool_reach_per_layer = p_reaches

today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
log_dir = f"./{name}/{today}"

res_dict = {
        'lr': learning_rate,
        'results': []
    }


for i in range(N_ITERATIONS):
    one_step_gtcnn = ParametricNetWithPoolingOrdered(
        window=obs_window,
        cyclic_time_graph=cyclic,
        time_directed=time_directed,
        S_spatial=weighted_adjacency,
        n_feat_per_layer=feat_per_layer,
        n_taps_per_layer=taps_per_layer,
        n_active_nodes_per_timestep_per_layer=active_nodes_per_timestep_per_layer,
        time_pooling_ratio_per_layer=time_pooling_ratio_per_layer,
        pool_reach_per_layer=pool_reach_per_layer,
        output_dim=N_spatial_nodes,
        device=device)
    one_step_gtcnn.to(device)
    print(one_step_gtcnn)

    model_parameters = filter(lambda p: p.requires_grad, one_step_gtcnn.parameters())
    params = sum([np.prod(p.size()) for p in model_parameters])
    print(f"Number of parameters: {params}")

    check_create_folder(log_dir)

    ### TRAINING ###
    # loss_criterion = rNMSELossWithSparsityRegularizer(one_step_gtcnn, lambda_reg)
    loss_criterion = MSELossWithSparsityRegularizer(one_step_gtcnn, lambda_value)

    val_metric = rNMSELoss()

    optimizer = torch.optim.Adam(one_step_gtcnn.parameters(), lr=learning_rate, weight_decay=weight_decay)
    scheduler = ReduceLROnPlateau(optimizer, 'min', patience=patience, factor=factor)

    best_model, best_epoch = train_model_regression(
        model=one_step_gtcnn,
        training_data=trn_data, validation_data=val_data,  # [n_samples x 1 x nodes x timesteps]
        single_step_trn_labels=one_step_trn_labels, single_step_val_labels=one_step_val_labels,  # [n_samples x spatial_nodes]
        num_epochs=num_epochs, batch_size=batch_size,
        loss_criterion=loss_criterion, optimizer=optimizer, scheduler=scheduler,
        val_metric_criterion=val_metric,
        log_dir=log_dir,
        not_learning_limit=not_learning_limit
    )



    orig_dataset, _, _ = get_NOAA_dataset(
        ds_folder,
        splits=splits,
        obs_window=obs_window,
        differenced=False,
    )
    _, _, _, _, _, orig_tst_labels = transform_data_to_all_steps_prediction(orig_dataset,
                                                                                                        node_first=True,
                                                                                                        device=device)


    orig_tst_labels = orig_tst_labels.float()


    deltas_predictions_dict, cum_delta_pred_dict_tst = perform_step_ahead_deltas(tst_data_deltas, best_model, steps_ahead,
                                                                                 verbose=True)
    tst_rNMSEs, _ = compute_iteration_rNMSE_with_deltas(
        cumulative_deltas_dict=cum_delta_pred_dict_tst,
        original_one_step_labels=orig_tst_labels[:, 0, :],
        verbose=True
    )

    print("rNMSEs: ", tst_rNMSEs)
    avg_tst_rNMSEs = round(np.average(tst_rNMSEs), 5)
    tst_values = (avg_tst_rNMSEs, tst_rNMSEs)
    print(tst_values[1])

    res_dict['results'].append(tst_rNMSEs)

    means = [round(el, 4) for el in np.average(res_dict['results'], axis=0)]
    stds = [round(el, 4) for el in np.std(res_dict['results'], axis=0)]
    res_dict['final_res'] = {
        'avg': means,
        'std': stds
    }

    with open(log_dir + '/results.json', 'w', encoding='utf-8') as f:
        json.dump(res_dict, f, ensure_ascii=False, indent=4)

    print(res_dict['results'])


print(res_dict['results'])
means = [round(el, 4) for el in np.average(res_dict['results'], axis=0)]
stds = [round(el, 4) for el in np.std(res_dict['results'], axis=0)]
print(means)
print(stds)

res_dict['final_res'] = {
    'avg': means,
    'std': stds
}
with open(log_dir + '/results.json', 'w', encoding='utf-8') as f:
    json.dump(res_dict, f, ensure_ascii=False, indent=4)