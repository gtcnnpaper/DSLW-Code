import datetime
import json

import numpy as np
from itertools import product
import torch
from torch import nn
from torch.optim.lr_scheduler import ReduceLROnPlateau

from architectures.space_time.grnn_ruiz.architecture import GatedGCRNNforRegression
from prediction.NOAA.difference_utils import visualize_predictions, visualize_deltas, perform_step_ahead_deltas, \
    compute_iteration_rNMSE_with_deltas
from prediction.train_utils import train_model_regression
from prediction.pred_utils import get_device, transform_data_to_all_steps_prediction, get_NOAA_dataset
from utils.misc_utils import check_create_folder

torch.cuda.current_device()
torch.set_default_dtype(torch.float64)



# torch.manual_seed(123)
# np.random.seed(123)
# random.seed(123)

device = get_device(use_gpu=True)

ds_folder = "../"
splits = [0.35, 0.15, 0.5]
obs_window = 4
DIFFERENCE = True

data, steps_ahead, weighted_adjacency = get_NOAA_dataset(
    ds_folder,
    splits=splits,
    obs_window=obs_window,
    differenced=DIFFERENCE,
)
N_spatial_nodes = weighted_adjacency.shape[0]
print(f"{N_spatial_nodes} nodes - {obs_window} observed timesteps - steps ahead: {steps_ahead}")










# Get data
trn_data, val_data, tst_data_deltas, trn_labels, val_labels, tst_labels_deltas = transform_data_to_all_steps_prediction(data, node_first=True, device=device)
print("Trn data size: ", trn_data.shape)

# obtain one-step labels for the training
one_step_trn_labels = trn_labels[:, 0, :]  # [batch x step-ahead x nodes]
one_step_val_labels = val_labels[:, 0, :]
print("Trn labels size: ", one_step_trn_labels.shape)

today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")


N_ITERATIONS = 5
learning_rate = 0.001
batch_size = 128
num_epochs = 150
F1 = 3 # Number of features for the first layer
K1 = 2 # Number of filter taps for the first layer, or number of attention heads

log_dir = f"./runs_NOAA_w={obs_window}_GGRNN/{today}_lr={learning_rate}_b={batch_size}"

res_dict = {
        'lr': learning_rate,
        'f1': F1,
        'k1': K1,
        'results': []
    }


for i in range(N_ITERATIONS):

    grnn_model = GatedGCRNNforRegression(
            inFeatures=1,
            stateFeatures=F1,
            inputFilterTaps=K1,
            stateFilterTaps=K1,
            stateNonlinearity=nn.functional.tanh,
            outputNonlinearity=nn.ReLU,
            dimLayersMLP=[N_spatial_nodes],
            GSO=weighted_adjacency,
            bias=True,
            time_gating=True,
            spatial_gating=None,
            # mlpType='multipMlp'
        )
    grnn_model.to(device)
    print(grnn_model)

    model_parameters = filter(lambda p: p.requires_grad, grnn_model.parameters())
    params = sum([np.prod(p.size()) for p in model_parameters])
    print(f"Number of parameters: {params}")


    criterion = torch.nn.MSELoss()
    optimizer = torch.optim.Adam(grnn_model.parameters(), lr=learning_rate, weight_decay=0)

    best_ggrnn, best_epoch = train_model_regression(
        model=grnn_model,
        training_data=trn_data, validation_data=val_data,  # [n_samples x 1 x nodes x timesteps]
        single_step_trn_labels=one_step_trn_labels, single_step_val_labels=one_step_val_labels,
        # [n_samples x spatial_nodes]
        num_epochs=num_epochs, batch_size=batch_size,
        loss_criterion=criterion, optimizer=optimizer, scheduler=None,
        val_metric_criterion=None,
        log_dir=log_dir,
        not_learning_limit=10
    )

    orig_dataset, _, _ = get_NOAA_dataset(
        ds_folder,
        splits=splits,
        obs_window=obs_window,
        differenced=False,
    )
    _, _, _, orig_trn_labels, orig_val_labels, orig_tst_labels = transform_data_to_all_steps_prediction(orig_dataset,
                                                                                                        node_first=True,
                                                                                                        device=device)

    deltas_predictions_dict, cum_delta_pred_dict_tst = perform_step_ahead_deltas(tst_data_deltas, best_ggrnn, steps_ahead,
                                                                                 verbose=True)
    tst_rNMSEs, _ = compute_iteration_rNMSE_with_deltas(
        cumulative_deltas_dict=cum_delta_pred_dict_tst,
        original_one_step_labels=orig_tst_labels[:, 0, :],
        verbose=True
    )

    print("rNMSEs: ", tst_rNMSEs)
    avg_tst_rNMSEs = round(np.average(tst_rNMSEs), 5)
    tst_values = (avg_tst_rNMSEs, tst_rNMSEs)
    print(tst_values[1])

    # visualize_predictions(
    #     cum_delta_pred_dict_tst,
    #     orig_tst_labels[:, 0, :],
    #     start=1000,
    #     width=600,
    #     node=60,
    #     type_of_data='Test'
    # )
    #
    # visualize_deltas(
    #     deltas_predictions_dict,
    #     tst_labels_deltas,
    #     start=0,
    #     width=88,
    #     node=60,
    #     type_of_data='Test'
    # )

    res_dict['results'].append(tst_rNMSEs)

    means = [round(el, 4) for el in np.average(res_dict['results'], axis=0)]
    stds = [round(el, 4) for el in np.std(res_dict['results'], axis=0)]
    res_dict['final_res'] = {
        'avg': means,
        'std': stds
    }

    with open(log_dir + '/results.json', 'w', encoding='utf-8') as f:
        json.dump(res_dict, f, ensure_ascii=False, indent=4)

    print(res_dict['results'])

print(res_dict['results'])
means = [round(el, 4) for el in np.average(res_dict['results'], axis=0)]
stds = [round(el, 4) for el in np.std(res_dict['results'], axis=0)]
print(means)
print(stds)

res_dict['final_res'] = {
    'avg': means,
    'std': stds
}
with open(log_dir + '/results.json', 'w', encoding='utf-8') as f:
    json.dump(res_dict, f, ensure_ascii=False, indent=4)