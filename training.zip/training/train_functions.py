# 2019/01/10~2018/07/12
# Fernando Gama, fgama@seas.upenn.edu
# modified by Gabriele Mazzola, g.mazzola@student.tudelft.nl 11/09/2019

"""
train.py Training Module

Methods for training the models.

MultipleModels: Handles the training for multiple models simultaneously
"""

import datetime
import os
import pickle

import numpy as np
import torch

from utils.misc_utils import check_create_folder


def train_model(model, data, n_epochs, batch_size: int, **kwargs):
    """
    Trains a single Model

    Inputs:

        data (class): Data to carry out the training (see Utils.dataTools)
        num_of_epochs (int): number of epochs (passes over the dataset)
        batch_size (int): size of each minibatch

        Keyword arguments:

        validationInterval (int): interval of training (number of training
            steps) without running a validation stage.

        Optional (keyword) arguments:

        learningRateDecayRate (float): float that multiplies the latest learning
            rate used.
        learningRateDecayPeriod (int): how many training steps before
            multiplying the learning rate decay rate by the actual learning
            rate.
        > Obs.: Both of these have to be defined for the learningRateDecay
              scheduler to be activated.
        logger (Visualizer): save tensorboard logs.
        saveDir (string): path to the directory where to save relevant training
            variables.
        printInterval (int): how many training steps after which to print
            partial results (0 means do not print)
        graphNo (int): keep track of what graph realization this is
        realitizationNo (int): keep track of what data realization this is
        >> Alternatively, these last two keyword arguments can be used to keep
            track of different trainings of the same net

    Observations:
    - Model parameters for best and last are saved.

    """

    assert n_epochs > 0
    assert batch_size > 0
    NOT_IMPROVING_LIMIT = 200
    not_learning_count = 0

    # Training Options:
    doLogging = False
    logger = None
    modeLoss = 'Loss'
    modeEval = 'Accuracy'
    if 'logger' in kwargs.keys():
        doLogging = True
        logger = kwargs['logger']

    doSaveVars = False
    saveDir = None
    if 'saveDir' in kwargs.keys():
        doSaveVars = True
        saveDir = os.path.join(kwargs['saveDir'], 'trainVars')

    doPrint = False
    printInterval = None
    if 'printInterval' in kwargs.keys():
        doPrint = True
        printInterval = kwargs['printInterval']

    if 'validationInterval' not in kwargs.keys():
        raise Exception("Need to specify a validationInterval")
    validationInterval = kwargs['validationInterval']

    tracking_dict = None
    if 'tracking' in kwargs.keys():
        tracking_dict = {}
        for param_name in kwargs['tracking']:
            tracking_dict[param_name] = []

    nTrain = data.nTrain  # size of the training set

    # Number of batches: If the desired number of batches does not split the
    # dataset evenly, we reduce the size of the last batch (the number of
    # samples in the last batch).
    # The variable batch_sizes is a list of length n_batches (number of batches),
    # where each element of the list is a number indicating the size of the
    # corresponding batch.
    if nTrain < batch_size:
        raise Exception("Are you sure values are correct?")
        # n_batches = 1
        # batch_sizes = [nTrain]
    elif nTrain % batch_size != 0:
        # if they cannot be split perfectly, we need to do it manually
        n_batches = np.ceil(nTrain / batch_size).astype(np.int64)
        batch_sizes = [batch_size] * n_batches

        while sum(batch_sizes) != nTrain:
            # If the sum of all batches so far is not the total number of graphs,
            # start taking away samples from the last batch (remember that we used
            # ceiling, so we are overshooting with the estimated number of batches)
            batch_sizes[-1] -= 1
    else:
        # If they fit evenly, then just do so.
        n_batches = np.int(nTrain / batch_size)
        batch_sizes = [batch_size] * n_batches

    # batch_indices is used to determine the first and last element of each batch.
    # If batch_size is, for example [20,20,20] meaning that there are three
    # batches of size 20 each, then cumsum will give [20,40,60] which determines
    # the last index of each batch: up to 20, from 20 to 40, and from 40 to 60.
    # We add the 0 at the beginning so that batch_indices[b]:batch_indices[b+1] gives
    # the right samples for batch b.
    batch_indices = np.cumsum(batch_sizes).tolist()
    batch_indices = [0] + batch_indices

    ##############
    # TRAINING   #
    ##############

    # \\\ Save variables to be used for logging
    lossTrainTB = None
    evalTrainTB = None
    lossValidTB = None
    evalValidTB = None
    if doLogging:
        lossTrainTB = {}
        evalTrainTB = {}
        lossValidTB = {}
        evalValidTB = {}

    # Training variables of interest
    lossTrain = []
    evalTrain = []
    lossValid = []
    evalValid = []
    timeTrain = []
    timeValid = []

    # Model tracking
    bestScore = {}
    bestEpoch = {}
    bestBatch = {}

    for epoch_id in range(n_epochs):
        # Randomize dataset for each epoch
        randomPermutation = np.random.permutation(nTrain)  # TODO: is this necessary?
        # Convert a numpy.array of numpy.int into a list of actual int.
        permuted_data = [int(i) for i in randomPermutation]

        for batch_id in range(n_batches):

            # Extract the adequate batch
            samples_to_get = permuted_data[batch_indices[batch_id]: batch_indices[batch_id + 1]]
            # Get the samples
            xTrain, yTrain = data.getSamples('train', samples_to_get)

            if doPrint and printInterval > 0:
                if (epoch_id * n_batches + batch_id) % printInterval == 0:
                    print(f"[TRAINING - E: {epoch_id + 1}, B: {batch_id + 1}]")

            # Start measuring time
            startTime = datetime.datetime.now()

            # Reset gradients
            model.archit.zero_grad()

            # Obtain the output of the GNN
            yHatTrain = model.archit(xTrain)

            # Compute loss
            lossValueTrain = model.loss(
                yHatTrain,
                yTrain.type(torch.int64),
                list(model.archit.named_parameters()),
                alpha=kwargs['alpha'])

            # Compute gradients
            lossValueTrain.backward()

            # Optimize
            model.optim.step()

            # Finish measuring time
            endTime = datetime.datetime.now()

            timeElapsed = abs(endTime - startTime).total_seconds()

            if tracking_dict:
                model_parameters = dict(model.archit.named_parameters())
                #print(model_parameters.keys())
                for param_name in tracking_dict:
                    tracking_dict[param_name].append(model_parameters[param_name].item())

            # Compute the accuracy
            #   Note: Using yHatTrain.data creates a new tensor with the
            #   same value, but detaches it from the gradient, so that no
            #   gradient operation is taken into account here.
            #   (Alternatively, we could use a with torch.no_grad():)
            with torch.no_grad():
                accTrain = data.evaluate(yHatTrain.cpu(), yTrain.cpu())

            # Logging values
            if doLogging:
                lossTrainTB = lossValueTrain.item()
                evalTrainTB = accTrain.item()
            # Save values
            lossTrain += [lossValueTrain.item()]
            evalTrain += [accTrain.item()]
            timeTrain += [timeElapsed]

            # Print:

            if doPrint and printInterval > 0:
                if (epoch_id * n_batches + batch_id) % printInterval == 0:
                    print(f"\t trn_acc: {round(accTrain.item(), 4)}"
                          f"\t trn_loss: {round(lossValueTrain.item(), 4)}"
                          f"\t f_pass_time: {round(timeElapsed, 4)}s")
            # \\\\\\\
            # \\\ TB LOGGING (for each batch)
            # \\\\\\\

            if doLogging:
                logger.scalar_summary(mode=f'Training{modeLoss}', epoch=epoch_id * n_batches + batch_id, **lossTrainTB)
                logger.scalar_summary(mode=f'Training{modeEval}', epoch=epoch_id * n_batches + batch_id, **evalTrainTB)

            # \\\\\\\
            # \\\ VALIDATION
            # \\\\\\\

            if (epoch_id * n_batches + batch_id) % validationInterval == 0:
                # Validation:
                xValid, yValid = data.getSamples('valid')  # we take all of them

                if doPrint:
                    print(f"[VALIDATION - E: {epoch_id + 1}, B: {batch_id + 1}]")

                # Start measuring time
                startTime = datetime.datetime.now()

                with torch.no_grad():
                    # Obtain the output of the GNN
                    yHatValid = model.archit(xValid)

                    # Compute loss # TODO: make the l1_norm optional
                    lossValueValid = model.loss(
                        yHatValid,
                        yValid.type(torch.int64),
                        list(model.archit.named_parameters()),
                        alpha=kwargs['alpha'])

                    # Finish measuring time
                    endTime = datetime.datetime.now()

                    timeElapsed = abs(endTime - startTime).total_seconds()

                    # Compute accuracy:
                    accValid = data.evaluate(yHatValid.cpu(), yValid.cpu())

                    # Logging values
                    if doLogging:
                        lossValidTB = lossValueValid.item()
                        evalValidTB = accValid.item()

                    # Save values
                    lossValid += [lossValueValid.item()]
                    evalValid += [accValid.item()]
                    timeValid += [timeElapsed]

                    # Print:
                    if doPrint:
                        print(f"\t val_acc: {round(accValid.item(), 4)}"
                              f"\t val_loss: {round(lossValueValid.item(), 4)}"
                              f"\t f_pass_time: {round(timeElapsed, 4)}s"
                              f"\t not_learning_count: {not_learning_count}")

                first_batch_ever = True if (epoch_id == 0 and batch_id == 0) else False
                if first_batch_ever:
                    # No previous best option, so let's record the first trial
                    # as the best option
                    bestScore = accValid
                    bestEpoch, bestBatch = epoch_id, batch_id
                    # Save this net as the best (so far)
                    model.save(label='Best')
                else:
                    # any other case other than the first batch ever.
                    thisValidScore = accValid
                    if thisValidScore > bestScore:
                        not_learning_count = 0
                        bestScore = thisValidScore
                        bestEpoch, bestBatch = epoch_id, batch_id
                        model.save(label='Best')

                        if doPrint:
                            print(f"\t\t\t=> New best validation accuracy: {round(bestScore.item(), 4)}")
                    else:
                        not_learning_count += 1

                if doLogging:
                    logger.scalar_summary(mode=f'Validation{modeLoss}', epoch=epoch_id * n_batches + batch_id, **lossValidTB)
                    logger.scalar_summary(mode=f'Validation{modeEval}', epoch=epoch_id * n_batches + batch_id, **evalValidTB)

            # \\\\\\\
            # \\\ END OF BATCH
            # \\\\\\\

        # \\\\\\\
        # \\\ END OF EPOCH
        # \\\\\\\

    # \\\ Save net:
    model.save(label='Last')

    #################
    # TRAINING OVER #
    #################
    # We convert the lists into np.arrays to be handled by matplotlib
    lossTrain = np.array(lossTrain)
    evalTrain = np.array(evalTrain)
    timeTrain = np.array(timeTrain)
    lossValid = np.array(lossValid)
    evalValid = np.array(evalValid)
    timeValid = np.array(timeValid)

    if doSaveVars:
        # And we would like to save all the relevant information from training
        check_create_folder(saveDir)

        # Dictionaries of variables to save
        vars_pickle = {'num_of_epochs': n_epochs,
                       'n_batches': n_batches,
                       'validationInterval': validationInterval,
                       'batch_sizes': np.array(batch_sizes),
                       'batchIndex': np.array(batch_indices),
                       'lossTrain': lossTrain,
                       'evalTrain': evalTrain,
                       'timeTrain': timeTrain,
                       'lossValid': lossValid,
                       'evalValid': evalValid,
                       'timeValid': timeValid,
                       'params_tracking': tracking_dict
                       }
        # And let's start with pickle
        # Create file for pickling
        varsFilename = 'training_vars'
        # And add the information if this is a specific realization run
        # Create the file
        pathToFile = os.path.join(saveDir, varsFilename + '.pkl')
        # Open and save it
        with open(pathToFile, 'wb') as trainVarsFile:
            pickle.dump(vars_pickle, trainVarsFile)

    # After training is done, reload best net before proceeding to evaluation:
    model.load(label='Best')

    # \\\ Print out best:
    if doPrint and n_epochs > 0:
        print(f"\n\n\t\t\t=> Best validation achieved (Epoch: "
              f"{bestEpoch + 1}, Batch: {bestBatch + 1}) -> Accuracy:  {round(bestScore.item(), 4)}")

    meta = {
        'tracking': tracking_dict
    }
    return lossTrain, evalTrain, lossValid, evalValid, n_batches, bestScore, meta
