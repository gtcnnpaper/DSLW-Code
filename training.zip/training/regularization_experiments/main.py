import json
import os

import torch
import numpy as np
import random
import datetime
import networkx as nx
from torch import optim
import matplotlib.pyplot as plt

from architectures.components.losses import ce_loss_with_L1_norm_for_parametric_graph
from architectures.space_time.parametric_pooling_net_ordering import ParametricNetWithPoolingOrdered
from earthquakes.quakes_util import write_pickle
from training.model_copied import Model
from training.train_functions import train_model
from utils.data_utils import get_dataset
from utils.misc_utils import get_folders_in_dir
from utils.src_loc_utils import SourceLocalizationFromDataset
torch.cuda.current_device()
torch.set_default_tensor_type(torch.FloatTensor)

use_gpu = True
if use_gpu and torch.cuda.is_available():
    device = 'cuda:0'
    torch.cuda.empty_cache()
else:
    device = 'cpu'
print("Device selected: %s" % device)




regularizer_weights = [0.00025, 0.00075, 0.00175]
obs_window = 2
learning_rate = 0.001
beta1 = 0.9
beta2 = 0.999
lossFunction = ce_loss_with_L1_norm_for_parametric_graph
num_of_epochs = 800  # 1200 # Number of epochs
batch_size = 100  # Batch size

for idx, reg_weight in enumerate(regularizer_weights):

    regularizer_weight = reg_weight
    DATASET_PATH = os.path.join("..", "..", "datasets", "20200609171214_overlap=False_splits")
    date = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    print(f"Dataset: {DATASET_PATH}")
    print(f"Training on observation window: {obs_window}")
    print(f"L1_norm alpha: {regularizer_weight}")

    # Logging Parameters:
    printInterval = 0  # After how many training steps, print the partial results. if 0 never print training partial results
    trainingOptions = {
        'printInterval': printInterval,
        'validationInterval': 20,
        'alpha': regularizer_weight
    }


    filename = f"weight={regularizer_weight}"
    saveDirRoot = os.path.join(".", "logs")  # Relative location where to save the file
    saveDir = os.path.join(saveDirRoot, filename)  # Dir where to save all the results from each run
    today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    saveDir = saveDir + '-' + today
    varsFile = os.path.join(saveDir, 'hyperparameters.txt')
    saveDirFigs = os.path.join(saveDir, 'figs')
    pathToTrainVars = os.path.join(saveDir, 'trainVars')


    product_graph_parameters = {}

    nBatches = None

    training_losses = []
    validation_losses = []
    training_accuracies = []
    validation_accuracies = []
    best_scores = []

    graphs_filepaths = get_folders_in_dir(DATASET_PATH)
    print(f"Found {len(graphs_filepaths)} graph folders.")
    for graph_number, graph_filepath in enumerate(graphs_filepaths):
        print(f"\nGraph {graph_number}")

        iteration_training_losses = []
        iteration_validation_losses = []
        iteration_training_accuracies = []
        iteration_validation_accuracies = []
        iteration_best_scores = []
        iteration_parameters_tracking = {}
        for param in product_graph_parameters:
            iteration_parameters_tracking[param] = []

        splits_filepaths = get_folders_in_dir(os.path.join(graph_filepath, f"w={obs_window}"))
        print(f"Found {len(splits_filepaths)} split folders.")

        adj_matrix = torch.load(os.path.join(graph_filepath, 'adj_matrix.pt'))

        spatial_graph = nx.from_numpy_matrix(adj_matrix.numpy())
        S_spatial = torch.from_numpy(np.array(nx.adjacency_matrix(spatial_graph).todense())).numpy()

        for split_number, split_filepath in enumerate(splits_filepaths):
            trn_data, trn_labels, val_data, val_labels, tst_data, tst_labels = get_dataset(split_filepath)
            print(f"Split {split_number}")

            trn_data = trn_data.permute(0, 2, 1).unsqueeze(1)
            val_data = val_data.permute(0, 2, 1).unsqueeze(1)
            tst_data = tst_data.permute(0, 2, 1).unsqueeze(1)

            dataset = SourceLocalizationFromDataset(trn_data, trn_labels, val_data, val_labels, tst_data, tst_labels)
            dataset.to(device)
            dataset.device = device

            print("\n\nCreating the architecture.")
            net = ParametricNetWithPoolingOrdered(
                window=obs_window,
                cyclic_time_graph=True,
                time_directed=True,
                S_spatial=S_spatial,
                n_feat_per_layer=[1, 2, 2],
                n_taps_per_layer=[2, 2],
                n_active_nodes_per_timestep_per_layer=[100, 100, 100],
                time_pooling_ratio_per_layer=[1, 1],
                pool_reach_per_layer=[1, 1],
                output_dim=5,
                device=device
            )
            print(net)
            model_parameters = filter(lambda p: p.requires_grad, net.parameters())
            params = sum([np.prod(p.size()) for p in model_parameters])
            print(f"Number of parameters: {params}")
            net.to(device)

            thisOptim = optim.Adam(net.parameters(), lr=learning_rate, betas=(beta1, beta2))
            model = Model(net, lossFunction, thisOptim, 'ParametricNetWithPooling', saveDir, order=None)

            print(f"\nStart training on graph {graph_number}, split {split_number}")
            loss_train, eval_train, loss_valid, eval_valid, nBatches, best_score, meta = train_model(
                model,
                dataset,
                n_epochs=num_of_epochs,
                batch_size=batch_size,
                **trainingOptions
            )


            # Saving results
            iteration_training_losses.append(loss_train)
            iteration_training_accuracies.append(eval_train)
            iteration_validation_losses.append(loss_valid)
            iteration_validation_accuracies.append(eval_valid)
            iteration_best_scores.append(best_score.item())

            # for param in iteration_parameters_tracking:
            #     iteration_parameters_tracking[param].append(meta['tracking'][param])
            # if iteration_parameters_tracking:
            #     # we have stuff to plot
            #     if not os.path.exists(saveDirFigs):
            #         os.makedirs(saveDirFigs)
            #
            #     values_dict = {}
            #     for matching_string in ['0.s', '3.s']:
            #         path_to_save = os.path.join(saveDirFigs, f"product_graph_parameters_i{graph_number}_s{split_number}_{matching_string}.pdf")
            #
            #         plt.figure()
            #         parameter_names = [param_name for param_name in iteration_parameters_tracking if matching_string in param_name]
            #         for param_name in parameter_names:
            #             values_dict[param_name] = iteration_parameters_tracking[param_name][-1]
            #
            #             x_axis = list(range(1, len(values_dict[param_name]) + 1))
            #             label = param_name.split(".")[2]
            #             plt.plot(x_axis, values_dict[param_name], label=label)  # plotting t, a separately
            #
            #         plt.legend()
            #         plt.ylabel('Weight')
            #         plt.xlabel('Training steps')
            #         plt.tight_layout()
            #         plt.savefig(path_to_save, bbox_inches='tight')
            #         plt.show()
            #
            #     pickle_dir = os.path.join(saveDirFigs, f"s_ij_parameters_i{graph_number}_s{split_number}.pickle")
            #     write_pickle(values_dict, pickle_dir)


            # END OF SPLIT

        # END OF GRAPH ITERATION
        # iteration_training_losses (and similar) is a list of lists. Each list contains the log of one training.
        training_losses += iteration_training_losses
        validation_losses += iteration_validation_losses
        training_accuracies += iteration_training_accuracies
        validation_accuracies += iteration_validation_accuracies
        best_scores += iteration_best_scores

        avg_train_loss_iter = np.mean(np.array(iteration_training_losses), axis=0)
        avg_train_acc_iter = np.mean(np.array(iteration_training_accuracies), axis=0)
        avg_val_loss_iter = np.mean(np.array(iteration_validation_losses), axis=0)
        avg_val_acc_iter = np.mean(np.array(iteration_validation_accuracies), axis=0)


        print("Best scores achieved")
        print([round(score, 3) for score in iteration_best_scores])
        print(f"Mean: {np.mean(iteration_best_scores)}")
        print(f"Std: {np.std(iteration_best_scores)}")

        # END OF GRAPH ITERATION


    # END OF ALL TRAINING
    avg_train_loss = np.mean(np.array(training_losses), axis=0)
    avg_train_acc = np.mean(np.array(training_accuracies), axis=0)
    avg_val_loss = np.mean(np.array(validation_losses), axis=0)
    avg_val_acc = np.mean(np.array(validation_accuracies), axis=0)


    print("Best scores achieved")
    print([round(score, 3) for score in best_scores])
    print(f"Mean: {np.mean(best_scores)}")
    print(f"Std: {np.std(best_scores)}")



    # save final results to a json dict
    final_results = {
        'best_scores': [best_scores]
    }

    with open(os.path.join(saveDir, "results.json"), 'w') as fp:
        json.dump(final_results, fp, indent=2)
