import datetime
import json
import os
import torch
from architectures.components.losses import ce_loss_with_L1_norm_for_parametric_graph

torch.set_default_dtype(torch.float64)

DATASET_NAME = "20200616084309_overlap=False"
DATASET_PATH = os.path.join("..", "datasets", DATASET_NAME)
RESULTS_PATH = os.path.join("..", "results")
GENERATION_METADATA_FILEPATH = os.path.join(DATASET_PATH, "data_generation_medatada.json")

with open(GENERATION_METADATA_FILEPATH, 'r') as f:
    gen_metadata = json.load(f)
sizes = gen_metadata['sizes']
nNodes = sum(sizes)
observation_windows = gen_metadata["observation_windows"]

observation_window = 2
in_features = 1
assert observation_window in observation_windows
n_feat_per_layer = [in_features, 32, 16]  # Features per layer (first element is the number of input features)
n_taps_per_layer = [2, 2]  # Number of filter taps per layer
n_active_nodes_per_timestep_per_layer = [nNodes, 75, 30]
time_pooling_ratio_per_layer = [1, 2]
pool_reach_per_layer = [1, 1]
output_dim = len(sizes)

seed = None

PLOT_EACH_TRAINING = False

# TRAINING PARAMETERS
num_of_epochs = 1200 # 1200 # Number of epochs
batch_size = 100  # Batch size
lossFunction = ce_loss_with_L1_norm_for_parametric_graph
trainer = 'ADAM'
learning_rate = 0.0025
l1_norm_alpha = 0 #0.0025
beta1 = 0.9
beta2 = 0.999
validationInterval = 20  # How many training steps to do the validation


trn_parameters = {
    "observation_window": observation_window,
    "n_feat_per_layer": n_feat_per_layer,
    "n_taps_per_layer": n_taps_per_layer,
    "n_active_nodes_per_timestep_per_layer": n_active_nodes_per_timestep_per_layer,
    "time_pooling_ratio_per_layer": time_pooling_ratio_per_layer,
    "pool_reach_per_layer": pool_reach_per_layer,
    "output_dim": output_dim,
    "num_of_epochs": num_of_epochs,
    "batch_size": batch_size,
    "learning_rate": learning_rate,
    "dataset": DATASET_NAME,
    'l1_alpha': l1_norm_alpha,
    'seed': seed
}

# LOGGING PARAMETERS
xAxisMultiplierTrain = 10  # How many training steps in between those shown in
# the plot, i.e., one training step every xAxisMultiplierTrain is shown.
xAxisMultiplierValid = 1  # How many validation steps in between those shown,
# same as above.
figSize = 5  # Overall size of the figure that contains the plot
lineWidth = 2  # Width of the plot lines
markerShape = 'o'  # Shape of the markers
markerSize = 3  # Size of the markers

# SAVING PARAMETERS
filename = f'w={observation_window}' if observation_window > 1 else 'w=1'
# This is the general name of all related files

model_descr = f"_F={n_feat_per_layer[1:]}_N={n_active_nodes_per_timestep_per_layer[:]}_P={time_pooling_ratio_per_layer}_reg={l1_norm_alpha}"
saveDirRoot = os.path.join("..", "logs")  # Relative location where to save the file
saveDir = os.path.join(saveDirRoot, filename)  # Dir where to save all the results from each run
today = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
saveDir = saveDir + '-' + today + model_descr
varsFile = os.path.join(saveDir, 'hyperparameters.txt')
saveDirFigs = os.path.join(saveDir, 'figs')
pathToTrainVars = os.path.join(saveDir, 'trainVars')
