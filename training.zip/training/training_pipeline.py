import json
import os

import torch
import numpy as np
import random
import datetime
import networkx as nx
from torch import optim
import matplotlib.pyplot as plt

from architectures.space_time.parametric_pooling_net_ordering import ParametricNetWithPoolingOrdered
from earthquakes.quakes_util import write_pickle
from training.model_copied import Model
from training.train_functions import train_model
from utils.data_utils import get_dataset
from training import training_config as trn_cfg
from utils.misc_utils import get_folders_in_dir, check_create_folder
from utils.plot_utils import plot_result
from utils.src_loc_utils import SourceLocalizationFromDataset
torch.cuda.current_device()
torch.set_default_tensor_type(torch.FloatTensor)

use_gpu = True
if use_gpu and torch.cuda.is_available():
    device = 'cuda:0'
    torch.cuda.empty_cache()
else:
    device = 'cpu'
print("Device selected: %s" % device)

if trn_cfg.seed:
    torch.manual_seed(trn_cfg.seed)
    np.random.seed(trn_cfg.seed)
    random.seed(trn_cfg.seed)

obs_window = trn_cfg.observation_window
date = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
print(f"Dataset: {trn_cfg.DATASET_PATH}")
print(f"Training on observation window: {obs_window}")
print(f"L1_norm alpha: {trn_cfg.l1_norm_alpha}")

# Logging Parameters:
printInterval = 0  # After how many training steps, print the partial results. if 0 never print training partial results
trainingOptions = {
    'printInterval': printInterval,
    'validationInterval': trn_cfg.validationInterval,
    'alpha': trn_cfg.l1_norm_alpha
}

product_graph_parameters = {}
doTracking = False
if obs_window > 1 and doTracking:
    trainingOptions['tracking'] = ['GFL.0.s_00',
                                   'GFL.0.s_01',
                                   'GFL.0.s_10',
                                   'GFL.0.s_11',
                                   'GFL.3.s_00',
                                   'GFL.3.s_01',
                                   'GFL.3.s_10',
                                   'GFL.3.s_11']
    for param in trainingOptions['tracking']:
        product_graph_parameters[param] = []

nBatches = None

training_losses = []
validation_losses = []
training_accuracies = []
validation_accuracies = []
best_scores = []

graphs_filepaths = get_folders_in_dir(trn_cfg.DATASET_PATH)
print(f"Found {len(graphs_filepaths)} graph folders.")
for graph_number, graph_filepath in enumerate(graphs_filepaths):
    print(f"\nGraph {graph_number}")

    iteration_training_losses = []
    iteration_validation_losses = []
    iteration_training_accuracies = []
    iteration_validation_accuracies = []
    iteration_best_scores = []
    iteration_parameters_tracking = {}
    for param in product_graph_parameters:
        iteration_parameters_tracking[param] = []

    splits_filepaths = get_folders_in_dir(os.path.join(graph_filepath, f"w={obs_window}"))
    print(f"Found {len(splits_filepaths)} split folders.")

    adj_matrix = torch.load(os.path.join(graph_filepath, 'adj_matrix.pt'))

    spatial_graph = nx.from_numpy_matrix(adj_matrix.numpy())
    S_spatial = torch.from_numpy(np.array(nx.adjacency_matrix(spatial_graph).todense())).numpy()

    for split_number, split_filepath in enumerate(splits_filepaths):
        trn_data, trn_labels, val_data, val_labels, tst_data, tst_labels = get_dataset(split_filepath)
        print(f"Split {split_number}")

        trn_data = trn_data.permute(0, 2, 1).unsqueeze(1)
        val_data = val_data.permute(0, 2, 1).unsqueeze(1)
        tst_data = tst_data.permute(0, 2, 1).unsqueeze(1)

        dataset = SourceLocalizationFromDataset(trn_data, trn_labels, val_data, val_labels, tst_data, tst_labels)
        dataset.to(device)
        dataset.device = device

        print("\n\nCreating the architecture.")
        net = ParametricNetWithPoolingOrdered(
            window=obs_window,
            cyclic_time_graph=True,
            time_directed=True,
            S_spatial=S_spatial,
            n_feat_per_layer=trn_cfg.n_feat_per_layer,
            n_taps_per_layer=trn_cfg.n_taps_per_layer,
            n_active_nodes_per_timestep_per_layer=trn_cfg.n_active_nodes_per_timestep_per_layer,
            time_pooling_ratio_per_layer=trn_cfg.time_pooling_ratio_per_layer,
            pool_reach_per_layer=trn_cfg.pool_reach_per_layer,
            output_dim=trn_cfg.output_dim,
            device=device
        )
        print(net)
        model_parameters = filter(lambda p: p.requires_grad, net.parameters())
        params = sum([np.prod(p.size()) for p in model_parameters])
        print(f"Number of parameters: {params}")
        net.to(device)

        thisOptim = optim.Adam(net.parameters(), lr=trn_cfg.learning_rate, betas=(trn_cfg.beta1, trn_cfg.beta2))
        model = Model(net, trn_cfg.lossFunction, thisOptim, 'ParametricNetWithPooling', trn_cfg.saveDir, order=None)

        print(f"\nStart training on graph {graph_number}, split {split_number}")
        loss_train, eval_train, loss_valid, eval_valid, nBatches, best_score, meta = train_model(
            model,
            dataset,
            n_epochs=trn_cfg.num_of_epochs,
            batch_size=trn_cfg.batch_size,
            **trainingOptions
        )


        # Saving results
        best = round(best_score.item(), 3)
        iteration_training_losses.append(loss_train)
        iteration_training_accuracies.append(eval_train)
        iteration_validation_losses.append(loss_valid)
        iteration_validation_accuracies.append(eval_valid)
        iteration_best_scores.append(best)

        # Storing results
        split_run_dir = os.path.join(trn_cfg.saveDir, "running_scores")
        check_create_folder(split_run_dir)
        iter_mean = np.average(iteration_best_scores)
        all_mean = np.average(best_scores)
        json_to_save = {
            'last_update': f"graph={graph_number}_split={split_number}",
            'iteration_best_scores': iteration_best_scores,
            'iteration_mean': iter_mean,
            'all_best_scores': best_scores,
            'all_mean': all_mean,
        }
        with open(os.path.join(split_run_dir, f"running_best_scores.json"), 'w') as fp:
            json.dump(json_to_save, fp, indent=2)

        if doTracking:
            for param in iteration_parameters_tracking:
                iteration_parameters_tracking[param].append(meta['tracking'][param])
            if iteration_parameters_tracking:
                # we have stuff to plot
                if not os.path.exists(trn_cfg.saveDirFigs):
                    os.makedirs(trn_cfg.saveDirFigs)

                values_dict = {}
                for matching_string in ['0.s', '3.s']:
                    path_to_save = os.path.join(trn_cfg.saveDirFigs, f"product_graph_parameters_i{graph_number}_s{split_number}_{matching_string}.pdf")

                    plt.figure()
                    parameter_names = [param_name for param_name in iteration_parameters_tracking if matching_string in param_name]
                    for param_name in parameter_names:
                        values_dict[param_name] = iteration_parameters_tracking[param_name][-1]

                        x_axis = list(range(1, len(values_dict[param_name]) + 1))
                        label = param_name.split(".")[2]
                        plt.plot(x_axis, values_dict[param_name], label=label)  # plotting t, a separately

                    plt.legend()
                    plt.ylabel('Weight')
                    plt.xlabel('Training steps')
                    plt.tight_layout()
                    plt.savefig(path_to_save, bbox_inches='tight')
                    plt.show()

                pickle_dir = os.path.join(trn_cfg.saveDirFigs, f"s_ij_parameters_i{graph_number}_s{split_number}.pickle")
                write_pickle(values_dict, pickle_dir)

        if trn_cfg.PLOT_EACH_TRAINING:
            # Compute the x-axis
            xTrain = np.arange(0, trn_cfg.num_of_epochs * nBatches, trn_cfg.xAxisMultiplierTrain)
            xValid = np.arange(0, trn_cfg.num_of_epochs * nBatches, trn_cfg.validationInterval * trn_cfg.xAxisMultiplierValid)

            if trn_cfg.xAxisMultiplierTrain > 1:
                selectSamplesTrain = xTrain
                loss_train = loss_train[selectSamplesTrain]
                eval_train = eval_train[selectSamplesTrain]

            if trn_cfg.xAxisMultiplierValid > 1:
                selectSamplesValid = np.arange(0, len(loss_valid), trn_cfg.xAxisMultiplierValid)
                loss_valid = loss_valid[selectSamplesValid]
                eval_valid = eval_valid[selectSamplesValid]

            legend = [r'Training', r'Validation']
            title = f'{model.name} - Iteration {graph_number} - Split {split_number}'
            fig_name = f"iter={graph_number}_split={split_number}"
            plot_result(trn_cfg, xTrain, xValid, loss_train, loss_valid, 'Training steps', 'Loss', legend, title, save=True,
                        plot=False, log=True, filename=fig_name + "_loss")
            plot_result(trn_cfg, xTrain, xValid, eval_train, eval_valid, 'Training steps', 'Accuracy', legend, title, save=True,
                        plot=False, log=False, filename=fig_name + "_acc")

        # END OF SPLIT

    # END OF GRAPH ITERATION
    # iteration_training_losses (and similar) is a list of lists. Each list contains the log of one training.
    training_losses += iteration_training_losses
    validation_losses += iteration_validation_losses
    training_accuracies += iteration_training_accuracies
    validation_accuracies += iteration_validation_accuracies
    best_scores += iteration_best_scores

    avg_train_loss_iter = np.mean(np.array(iteration_training_losses), axis=0)
    avg_train_acc_iter = np.mean(np.array(iteration_training_accuracies), axis=0)
    avg_val_loss_iter = np.mean(np.array(iteration_validation_losses), axis=0)
    avg_val_acc_iter = np.mean(np.array(iteration_validation_accuracies), axis=0)

    # Compute the x-axis
    xTrain = np.arange(0, trn_cfg.num_of_epochs * nBatches, trn_cfg.xAxisMultiplierTrain)
    xValid = np.arange(0, trn_cfg.num_of_epochs * nBatches, trn_cfg.validationInterval * trn_cfg.xAxisMultiplierValid)

    if trn_cfg.xAxisMultiplierTrain > 1:
        selectSamplesTrain = xTrain
        avg_train_loss_iter = avg_train_loss_iter[selectSamplesTrain]
        avg_train_acc_iter = avg_train_acc_iter[selectSamplesTrain]

    if trn_cfg.xAxisMultiplierValid > 1:
        selectSamplesValid = np.arange(0, len(avg_val_loss_iter), trn_cfg.xAxisMultiplierValid)
        avg_val_loss_iter = avg_val_loss_iter[selectSamplesValid]
        avg_val_acc_iter = avg_val_acc_iter[selectSamplesValid]

    legend = [r'Training', r'Validation']
    title = f'Graph {graph_number} (average results across splits)'
    fig_name = f"iter={graph_number}_avg"

    plot_result(trn_cfg, xTrain, xValid, avg_train_loss_iter, avg_val_loss_iter, 'Training steps', 'Loss', legend, title, True, False, log=True, filename=fig_name + "_loss")
    plot_result(trn_cfg, xTrain, xValid, avg_train_acc_iter, avg_val_acc_iter, 'Training steps', 'Accuracy', legend, title, True, False, log=False, filename=fig_name + "_acc")

    print("Best scores achieved")
    print([round(score, 3) for score in iteration_best_scores])
    print(f"Mean: {np.mean(iteration_best_scores)}")
    print(f"Std: {np.std(iteration_best_scores)}")

    # END OF GRAPH ITERATION


# END OF ALL TRAINING
avg_train_loss = np.mean(np.array(training_losses), axis=0)
avg_train_acc = np.mean(np.array(training_accuracies), axis=0)
avg_val_loss = np.mean(np.array(validation_losses), axis=0)
avg_val_acc = np.mean(np.array(validation_accuracies), axis=0)

# Compute the x-axis
xTrain = np.arange(0, trn_cfg.num_of_epochs * nBatches, trn_cfg.xAxisMultiplierTrain)
xValid = np.arange(0, trn_cfg.num_of_epochs * nBatches, trn_cfg.validationInterval * trn_cfg.xAxisMultiplierValid)

if trn_cfg.xAxisMultiplierTrain > 1:
    selectSamplesTrain = xTrain
    avg_train_loss = avg_train_loss[selectSamplesTrain]
    avg_train_acc = avg_train_acc[selectSamplesTrain]

if trn_cfg.xAxisMultiplierValid > 1:
    selectSamplesValid = np.arange(0, len(avg_val_loss), trn_cfg.xAxisMultiplierValid)
    avg_val_loss_iter = avg_val_loss[selectSamplesValid]
    avg_val_acc_iter = avg_val_acc[selectSamplesValid]

legend = [r'Training', r'Validation']
title = f'Total average'
fig_name = f"final"

plot_result(trn_cfg, xTrain, xValid, avg_train_loss, avg_val_loss, 'Training steps', 'Loss', legend, title, True, False, log=True, filename=fig_name + "_loss")
plot_result(trn_cfg, xTrain, xValid, avg_train_acc, avg_val_acc, 'Training steps', 'Accuracy', legend, title, True, False, log=False, filename=fig_name + "_acc")

print("Best scores achieved")
print([round(score, 3) for score in best_scores])
print(f"Mean: {np.mean(best_scores)}")
print(f"Std: {np.std(best_scores)}")


# Let's save the configuration used for this training run
with open(os.path.join(trn_cfg.saveDir, "training_medatada.json"), 'w') as fp:
    json.dump(trn_cfg.trn_parameters, fp, indent=2)

# save final results to a json dict
final_results = {
    'trn_losses': [list(l) for l in training_losses],
    'trn_accuracies': [list(l) for l in training_accuracies],
    'val_losses': [list(l) for l in validation_losses],
    'val_accuracies': [list(l) for l in validation_accuracies],
    'best_scores': [best_scores]
}

if obs_window > 1:
    final_results['tracking'] = product_graph_parameters
with open(os.path.join(trn_cfg.saveDir, "results.json"), 'w') as fp:
    json.dump(final_results, fp, indent=2)
