# 2018/10/02~2018/07/12
# Fernando Gama, fgama@seas.upenn.edu
"""
model.py Model Module

Utilities useful for working on the model

Model: binds together the architecture, the loss function and the optimizer
"""

import os
import torch


class Model:
    """
    Binds together in one class the architecture, the loss function and the
    optimizer. Printing an instance of the Model class gives all the information
    about the model.

    Attributes:

    archit: torch.nn.Module used for the architecture
    loss: torch loss function
    optim: torch optimizer
    name: model name
    saveDir: directory to save the model into
    order: order of nodes (needed to match the data to the GSO ordering)
    nParameters: number of learnable parameters
        >> Obs.: the nParameters count is not accurate if filters are
            Edge-Variant or Hybrid Edge-Variant

    Methods:

    save(saveDir, label = ''[, saveDir = pathToDir]):
        Saves the architecture and optimization states in the directory
        specified by saveDir/savedModels. (Obs.: Directory 'savedModels' is
        created).
        The naming convention is name + 'Archit' + label + '.ckpt' for the
        architecture, and name + 'Optim' + label + '.ckpt' for the optimizer.
        In both cases, name is the name of the model used for initialization.
        Optionally, another saveDir can be specified (this saveDir does not
        override the saveDir stored when the model was created)

    load(label = '' [, loadFiles = (af, of)]):
        Loads the state of a saved architecture.
        If no loadFiles are specified, then the architecture is load from the
        directory previously specified by saveDir when .save() was called. If
        this is the case, the fetched files have to be in savedModels and have
        the name convention as specified in the .save() documentation.
        If loadFiles is provided, then the states provided in af file path are
        loaded for the architecture and in of file path for the optimizer. If
        loadFiles are specified, the input label is ignored.

    train(data, num_of_epochs, batch_size, [optionalArguments]):
        Trains the model.
        Input:
            data (class): contains the data, requires methods getSamples() and
                evaluate()
            num_of_epochs (int): number of epochs (passes through the dataset)
            batch_size (int): size of the batch
            [optionalArguments:]
            doLogging (bool): log the training run in tensorboard
                (default: False)
            doSaveVars (bool): save training variables (default: True)
            printInterval (int): how many training steps between priting the
                training state through the output (0 means not show anything)
                (default: (numberTrainingSamples//batch_size)//5)
            learningRateDecayRate (float): multiplier of the learning rate after
                each epoch
            learningRateDecayPeriod (int): after how many epochs update the
                learning rate
            >> Obs.: Both need to be specified for learning rate decay to take
                place, by default, there is no learning rate decay.
            validationInterval (int): every how many training steps to carry out
                a validation step (default: numberTrainingSamples//batch_size)
            earlyStoppingLag (int): how many steps after a best in validation
                has been found to stop the training (default: no early stopping)

    evaluate (data):
        After the model has been trained, evaluates the data, both on the best
        model (following validation) and on the last model.
        Input:
            data (class): contains the data, requires methods getSamples() and
                evaluate()
        Output:
            evalBest (scalar): Evaluation performance, following data.evaluate()
                for the best model
            evalLast (scalar): Evaluation performance, following data.evaluate()
                for the last model

    getTrainingOptions():
        Return the actual training options used for training. If no training
        has been done through the .train method, then returns None.

    Example (Single model training):
        (For multiple model training, refer to Modules.train)

    Once we have initialized the architecture (archit), the loss function (loss)
    and the optimizer (optim), and have determined a name, a save directory
    (saveDir) and a node ordering (order), we initialize the model.

    thisModel = model.Model(archit, loss, optim, name, saveDir, order)

    Then, given the data (class with an .evaluate() and .getSamples() method as
    those defined in Utils.dataTools), the number of epochs (num_of_epochs), and the
    batch size (batch_size), together with the specific training options, we can
    train the model as

    thisModel.train(data, num_of_epochs, batch_size, [optional keyword arguments])

    Once the model is train, we can run the evaluation on the testing set
    (again, input the data class)

    evalBest, evalLast = thisModel.evaluate(data)

    Which prints the evaluation result and stores it in the output variables.
    """

    def __init__(self, architecture, loss, optimizer, name, saveDir, order=None):
        self.archit = architecture
        self.loss = loss
        self.optim = optimizer
        self.name = name
        self.saveDir = saveDir
        self.order = order
        self.trainingOptions = None

    def save(self, label='', **kwargs):
        if 'saveDir' in kwargs.keys():
            saveDir = kwargs['saveDir']
        else:
            saveDir = self.saveDir
        saveModelDir = os.path.join(saveDir, 'savedModels')
        # Create directory savedModels if it doesn't exist yet:
        if not os.path.exists(saveModelDir):
            os.makedirs(saveModelDir)
        saveFile = os.path.join(saveModelDir, self.name)
        torch.save(self.archit.state_dict(), saveFile + 'Archit' + label + '.ckpt')
        torch.save(self.optim.state_dict(), saveFile + 'Optim' + label + '.ckpt')

    def load(self, label='', **kwargs):
        if 'loadFiles' in kwargs.keys():
            (architLoadFile, optimLoadFile) = kwargs['loadFiles']
        else:
            saveModelDir = os.path.join(self.saveDir, 'savedModels')
            architLoadFile = os.path.join(saveModelDir,
                                          self.name + 'Archit' + label + '.ckpt')
            optimLoadFile = os.path.join(saveModelDir,
                                         self.name + 'Optim' + label + '.ckpt')
        self.archit.load_state_dict(torch.load(architLoadFile))
        self.optim.load_state_dict(torch.load(optimLoadFile))

    def getTrainingOptions(self):

        return self.trainingOptions


    def evaluate(self, data):
        raise Exception("Not checked")
        ########
        # DATA #
        ########

        xTest, yTest = data.getSamples('test')
        # Update order and adapt dimensions
        xTestOrdered = xTest[:, self.order].unsqueeze(1)

        ##############
        # BEST MODEL #
        ##############

        self.load(label='Best')

        if self.trainingOptions['doPrint']:
            print("Total testing accuracy (Best):", flush=True)

        with torch.no_grad():
            # Process the samples
            yHatTest = self.archit(xTestOrdered)
            # yHatTest is of shape
            #   testSize x numberOfClasses
            # We compute the accuracy
            accBest = data.evaluate(yHatTest, yTest)

        if self.trainingOptions['doPrint']:
            print("Evaluation (Best): %4.2f%%" % accBest)

        ##############
        # LAST MODEL #
        ##############

        self.load(label='Last')

        with torch.no_grad():
            # Process the samples
            yHatTest = self.archit(xTestOrdered)
            # yHatTest is of shape
            #   testSize x numberOfClasses
            # We compute the accuracy
            accLast = data.evaluate(yHatTest, yTest)

        if self.trainingOptions['doPrint']:
            print("Evaluation (Last): %4.2f%%" % accLast)

        return accBest, accLast

    def __repr__(self):
        reprString = "Name: %s\n" % (self.name)
        reprString += "Number of learnable parameters: %d\n" % (self.nParameters)
        reprString += "\n"
        reprString += "Model architecture:\n"
        reprString += "----- -------------\n"
        reprString += "\n"
        reprString += repr(self.archit) + "\n"
        reprString += "\n"
        reprString += "Loss function:\n"
        reprString += "---- ---------\n"
        reprString += "\n"
        reprString += repr(self.loss) + "\n"
        reprString += "\n"
        reprString += "Optimizer:\n"
        reprString += "----------\n"
        reprString += "\n"
        reprString += repr(self.optim) + "\n"
        return reprString
